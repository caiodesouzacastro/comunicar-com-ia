---
name: comunicar-evidencias
description: Transforma um texto de evidência (síntese, relatório, nota técnica) em versões curtas para outros públicos (resumo para liderança, roteiro de apresentação, nota interna) sem mudar o que a evidência diz, listando o trecho de apoio de cada frase e rodando a conferência como etapa separada. Use quando pedirem resumo executivo, versão para a diretoria, roteiro de apresentação, nota interna ou conferência de uma versão curta contra a fonte.
---

# Comunicar evidências sem mudar o que dizem

Esta skill faz versões curtas de um texto de evidência de um jeito que outra pessoa consegue conferir: cada frase aponta para um trecho literal da fonte. O objetivo não é escrever bonito; é chegar a uma versão em que nenhuma frase afirma mais do que a fonte.

## Regras que nunca mudam

1. Nada que não esteja no texto: nenhuma informação, número ou recomendação nova.
2. O grau de certeza de cada achado fica igual (efeito, sem efeito, inconclusivo). "Pode ter efeito" não vira "funciona".
3. País, etapa, público, formato e tamanho de cada estudo citado ficam ditos.
4. As limitações do método que a fonte declara entram na versão, inclusive as que só aparecem na seção de método.
5. Contagem só se a fonte contar. Não reorganize listas da fonte em "três fatores" ou "quatro prioridades".
6. Pergunta em aberto continua pergunta. Não transforme o que a fonte deixa em aberto em oportunidade ou recomendação.
7. Sem adjetivos de destaque e sem autoria ou endosso que a fonte não traz.
8. Todo número fica com a sua condição: o cenário, o grupo ou a rede, a referência de comparação, o ano e o sinal (aumenta ou diminui). Número certo sem a sua condição muda o que a fonte diz.

## Quem decide o quê

Você faz o trabalho mecânico e deixa o julgamento visível.
- Equipe: define público e decisão, decide frase a frase o que fica e revisa a versão de outra pessoa.
- Quem conhece o tema: confere a lista do que não pode mudar e as frases de fronteira.
Ao fim de cada entrega, diga em uma linha o que a equipe precisa conferir.

## Etapas

Pare ao fim de cada etapa e mostre o resultado para o usuário conferir antes de seguir.

### 1. Definir público e decisão
Pergunte quem vai ler e o que essa pessoa precisa decidir. Sem essa frase, não escreva a versão. Se o texto tiver dado pessoal ou informação restrita, avise e sugira a ferramenta institucional.

### 2. Marcar o que não pode mudar
Liste o achado principal, o grau de certeza de cada achado, o contexto dos estudos, as limitações do método e as recomendações que a fonte faz, cada item com o trecho literal e a página.

### 3. Escrever a versão com estrutura fixa
Use a estrutura do modelo pedido (`references/modelos.md`): resumo para liderança, roteiro de apresentação ou nota interna. No fim, liste as frases do texto original em que cada parte se apoia, com a página.

### 4. Conferir como etapa separada
Se puder, peça ao usuário que rode a conferência numa conversa nova. Se fizer a conferência aqui, trate a versão como texto de outra pessoa: para cada frase, cite o trecho literal e classifique como sustentada, afirma mais do que o original, não está no original ou muda o contexto. Regra da diferença: se a sua avaliação apontar qualquer diferença entre a frase e o original, a frase não pode ser classificada como sustentada. Para cada número, diga se a condição é a mesma do original; se não for, a frase muda o contexto. Liste à parte as limitações do original que a versão deixou de fora.

### 5. Preparar a decisão frase a frase
Devolva uma tabela com uma linha por frase: frase, trecho de apoio (ou "sem trecho"), página, classificação e uma coluna "decisão da equipe" em branco. Não decida pela equipe.

### 6. Apoiar a revisão por outra pessoa
Se pedirem revisão, aplique `references/checklist.md` à versão, com o original ao lado, apontando a frase que motivou cada resposta. Não reescreva.

### 7. Registrar
Organize o registro: público e decisão, fonte (autoria e data como estão no original), versão final, prompts usados, ferramenta, data e frases que mudaram depois da conferência.

## Dados

Texto com dado pessoal ou informação restrita não vai para ferramenta aberta. Avise antes de seguir.

## Para conferir

Feche toda entrega com uma seção curta "Para conferir": as frases classificadas como afirma mais, não está no original ou muda o contexto; toda contagem e todo número, com a página e a condição; as recomendações e o trecho que as sustenta; as limitações do método que não entraram; e o que pede revisão de quem conhece o tema. Use `references/checklist.md` e `references/erros-comuns.md`.
