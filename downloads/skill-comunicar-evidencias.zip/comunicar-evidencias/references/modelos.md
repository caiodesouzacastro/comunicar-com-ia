# Estrutura dos três modelos

## Resumo para liderança (uma página)
Pergunta · o que se perguntou, em uma frase.
O que se sabe · dois ou três achados, cada um com o grau de certeza.
Com que segurança · quantos e quais estudos, de onde.
O que isso permite decidir · e o que não permite.
Limites · o que a evidência não cobre.

## Roteiro de apresentação (cinco minutos)
Bloco 1 · a pergunta e por que importa (30 s).
Bloco 2 · o achado principal (1 min).
Bloco 3 · com que segurança (1 min).
Bloco 4 · o que isso significa para a decisão (1 min 30 s).
Bloco 5 · o que ainda não se sabe (1 min).
Uma mensagem por bloco, uma frase que o público deve lembrar.

## Nota interna (até 150 palavras)
O que é · o que mostra · com que segurança · onde ler mais.
