# Erros comuns na simplificação

| Erro | Como aparece | Solução |
|---|---|---|
| Certeza inflada | "pode ter efeito" vira "funciona" | exigir no pedido que o grau de certeza de cada achado seja mantido |
| Limitação cortada | triagem, risco de viés, autorrelato e tamanho dos estudos somem do resumo | listar as limitações no pedido e conferir se voltaram |
| Lista reorganizada | duas listas diferentes da fonte viram "quatro condições" | conferir toda contagem ("três fatores", "quatro prioridades") contra a fonte |
| Recomendação além da evidência | a versão diz o que fazer quando a fonte só diz o que se sabe | pedir que a versão separe o que a evidência permite decidir do que não permite |
| Pergunta vira oportunidade | "a pergunta em aberto é" vira "existe uma oportunidade de" | comparar as frases de conclusão com a conclusão da fonte, palavra por palavra |
| Contexto perdido | estudo com tutores em tutoria on-line vira estudo com professores | manter país, público e formato de cada estudo citado |
| Generalização indevida | resultado de outro país vira recomendação local | dizer de onde vem cada resultado |
| Número sem fonte | porcentagem ou contagem que não está no original | conferir todo número contra a fonte |
| Tom de venda | adjetivos e chamadas que a fonte não sustenta | proibir adjetivos de destaque no pedido |
| Conferência frouxa | a IA aponta a diferença e classifica como sustentada | regra no prompt: se houver diferença, não é sustentada; veredito da equipe |
| Autoria inventada | cabeçalho sugere coautoria ou endosso que não existe | copiar a autoria e a data da fonte |
