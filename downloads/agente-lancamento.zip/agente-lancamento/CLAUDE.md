# Agente de lançamento de estudo

## Objetivo

Transformar um estudo (relatório em PDF e, se houver, o resumo executivo) num kit de comunicação para públicos diferentes e em páginas interativas, conferido frase a frase contra a fonte, com o registro do que a conferência pegou.

Fio condutor de todas as etapas: **simplificar sem mudar o que a evidência diz.**

Simplificar é escolher o que entra, trocar jargão por palavra comum e encurtar. Mudar o que a evidência diz é arredondar um número para outro valor, tirar a condição de um número, transformar "pode" em "vai", trocar o cenário, a rede ou o ano, ou pôr na boca do estudo uma recomendação que ele não faz. A primeira coisa é o trabalho; a segunda é erro, mesmo quando deixa a frase melhor.

## Regras que valem para toda peça

1. **Nada fora da ficha de evidências.** Toda afirmação e todo número de uma peça saem de `saida/ficha-evidencias.md` ou de `saida/dados.json`. Se não está lá, não entra. Quem precisar de algo que falta pede ao leitor; não procura sozinho nem completa de memória.
2. **Todo número com a sua condição.** Um número só aparece junto do que o estudo diz que ele depende: cenário, rede (municipal, estadual, pública), referência de preço (despesa observada ou custo-padrão), ano, recorte territorial e número de unidades cobertas (N), quando a fonte informar. Em gráfico e tabela, a condição vai numa linha logo abaixo; em texto corrido, na mesma frase ou na seguinte.
3. **Grau de certeza mantido.** "Pode", "tende a", "estima-se", "em tese", "cerca de", "ordem de grandeza" ficam como estão. Projeção é apresentada como projeção, não como fato futuro.
4. **Limitações presentes.** Toda peça tem pelo menos uma frase com o que o estudo diz que não sabe ou não mede, tirada da seção de limitações da ficha. Peças longas trazem as limitações que afetam os números que usam.
5. **Sinal escrito por extenso.** Nada de "−12,3" ou "+4,5" soltos para o leitor decifrar. Escreva o que o sinal significa na convenção do estudo: "libera R$ 12,3 bilhões", "exige R$ 4,5 bilhões a mais". A convenção de sinal de cada tabela está em `dados.json`, bloco `regras_de_leitura`.
6. **Sem adjetivo de destaque.** Nada de "impressionante", "histórico", "alarmante", "enorme", "dramático", "expressivo" por conta própria. Só use um qualificativo se ele estiver na fonte, e então com a página.
7. **Sem recomendação que a fonte não faz.** A peça pode repetir uma recomendação do estudo, atribuída a ele. Não pode criar uma ("os municípios devem...") nem transformar um achado em ordem.
8. **Rodapé de protótipo.** Toda peça leva o rodapé definido para o caso em `lancamento.json` (campo `rodape`), sem alteração. Ele diz que é protótipo feito com IA, que não é material oficial e cita a fonte.

Regras de forma:

- Visual sóbrio, legível em projetor (corpo de texto a partir de 16 px em tela e 18 pt em slide), sem logo nem identidade visual de instituição. O nome das instituições só aparece na citação da fonte.
- Páginas HTML em arquivo único, sem internet: nada de CDN, fonte externa ou imagem remota. Gráficos em SVG desenhado pelo próprio código da página.
- Números em formato brasileiro (vírgula decimal, ponto de milhar), com a mesma casa decimal da fonte.
- Toda peça tem uma forma de chegar à fonte: página do relatório ou do resumo e, para tabelas, o número da tabela.

## Fluxo

```
fonte/ (PDFs)
   │
   ▼
1. LEITOR ──► saida/ficha-evidencias.md + saida/dados.json (tabelas por script, conferidas com um segundo extrator)
   │
   ▼
2. REDATORES (um por peça, em paralelo, só com a ficha e os dados) ──► saida/<peça>
   │
   ▼
3. CONFERÊNCIA, por peça e por rodada:
      VERIFICADOR (novo a cada rodada; só a peça e os PDFs)  ┐
      LEITOR APRESSADO (novo a cada rodada; só a peça e os PDFs) ┘──► EDITOR corrige e registra
   │   repete até o critério de parada
   ▼
4. RASTREABILIDADE (uma linha por frase com número) + BASTIDORES (o que foi pego, por quem, quanto tempo)
   │
   ▼
5. PAINEL de entrada, capturas de tela, conferência de links, pacote zip
```

Detalhe de cada etapa:

1. **Preparar.** Copie os PDFs para `fonte/` e gere o texto por página com `ferramentas/paginas_pdf.py`. Preencha `lancamento.json` na pasta do caso (título, rodapé, públicos, tabelas a transcrever). Registre o SHA256 dos PDFs.
2. **Leitor** (`.claude/agents/leitor.md`). Lê o estudo inteiro. Escreve a ficha e transcreve as tabelas pedidas por script, nunca digitando. Confere cada valor com um segundo extrator e lista as divergências.
3. **Redatores** (`.claude/agents/redator.md`). Um subagente por peça, todos ao mesmo tempo. Cada um recebe só a ficha, os dados, este arquivo e a especificação da peça. As peças em Word, PowerPoint e os cards são escritas em texto estruturado e montadas pelas ferramentas de `ferramentas/`; as páginas interativas são geradas por script que embute `dados.json`, para que nenhum número de tabela seja redigitado.
4. **Conferência.** Para cada peça e cada rodada, um verificador novo (`verificador.md`) e um leitor apressado novo (`leitor-apressado.md`), que não veem a ficha nem as rodadas anteriores. O editor (`editor.md`) recebe os dois relatórios, a ficha e os dados, corrige a peça e registra cada correção ou recusa. A peça é montada de novo e volta para a rodada seguinte.
5. **Rastreabilidade e bastidores.** Um script junta os relatórios em `saida/rastreabilidade.xlsx` e `saida/bastidores.md`. Nada é digitado à mão no placar.
6. **Painel e entrega.** O painel (`saida/painel.html`) é montado por script a partir das peças e dos registros. Capture as telas, confira os links, monte o zip e confira os links do zip extraído.

## Critério de parada da conferência

- A peça está pronta quando uma rodada de verificação encontra **zero "número errado" e zero "condição faltando ou trocada"**.
- Os outros tipos ("afirma mais do que a fonte", "não está na fonte") e os apontamentos do leitor apressado são corrigidos pelo editor em toda rodada, mas não seguram a peça sozinhos.
- Se, na rodada que zerou, o editor inserir ou alterar um número ou uma condição, a peça volta para mais uma rodada. Se ele só cortar ou suavizar texto, a peça sai.
- Limite de **três rodadas** por peça. Se a terceira ainda encontrar número errado ou condição faltando, a peça sai marcada como "não zerou" no painel e nos bastidores, com a lista do que ficou pendente. Nunca esconder.
- Na terceira rodada nada do que o editor mudar será verificado de novo. Por isso ele só corta, suaviza, troca verbo, reordena ou corrige página citada; não insere, tira nem altera número ou condição. O apontamento que só se resolveria assim fica recusado, com o motivo, e aparece como pendência nos bastidores.

## Registro

Cada subagente grava, no começo e no fim, a hora (`Get-Date -Format o` no PowerShell ou `date -Iseconds` no Bash) dentro do seu arquivo de saída, para que os bastidores tenham o tempo de cada etapa. Os relatórios ficam em `saida/conferencia/<peça>/rodada-N/`:

- `verificador.json`, `apressado.json`, `editor.json` (formatos definidos em cada subagente);
- `texto-da-peca.txt`, o texto extraído da peça montada, que é o que o verificador e o apressado leem.

## Estrutura de pastas de um caso

```
<caso>/
  lancamento.json         configuração do caso (título, rodapé, públicos, tabelas)
  fonte/                  PDFs do estudo (não vão para o pacote)
  agente-lancamento/      esta pasta, sem nada do estudo
  scripts/                scripts próprios do caso (extração das tabelas, montagem das páginas)
  saida/
    ficha-evidencias.md   dados.json
    <peças>               cards/  prints/
    conferencia/          bastidores.md  rastreabilidade.xlsx
    painel.html
```

## O que este agente não faz

- Não publica, não envia e não copia peças para fora da pasta do caso.
- Não usa nome, logo ou identidade visual das instituições do estudo além da citação da fonte.
- Não estima valor lendo gráfico do PDF: só texto e tabelas.
- Não guarda nada de um estudo específico dentro de `agente-lancamento/`.
