# Agente de lançamento de estudo

Esta pasta é um assistente de IA, já configurado, que pega um estudo em PDF e prepara o material para divulgá-lo: um resumo para a liderança, um brief para gestores, uma nota para imprensa, cards para redes sociais, uma apresentação e duas páginas interativas. Antes de entregar, ele confere cada frase contra o estudo e registra o que precisou corrigir.

A regra que guia tudo: **simplificar sem mudar o que a evidência diz.**

## O que ele faz, em cinco papéis

Pense numa pequena redação em que cada pessoa tem uma tarefa e não pode fazer a do outro.

| Papel | O que faz | O que pode ver |
|---|---|---|
| **Leitor** | Lê o estudo inteiro e monta uma ficha com cada achado: a frase original, a página, o número, a unidade e em que condição o número vale. Copia as tabelas por programa, sem digitar, e confere com um segundo programa. | O estudo inteiro |
| **Redator** | Escreve uma peça para um público. Há um redator por peça, todos trabalhando ao mesmo tempo. | Só a ficha e as tabelas. Não vê o estudo. |
| **Verificador** | Pega a peça pronta e procura cada frase e cada número no estudo. Diz se confere (com página e trecho) ou qual é o erro. | Só a peça e o estudo. Não vê a ficha nem o que já foi corrigido. |
| **Leitor apressado** | Lê a peça como um jornalista ou gestor com pressa e aponta a frase que, citada sozinha, faria o estudo dizer o que ele não diz. | Só a peça e o estudo. |
| **Editor** | Corrige o que os dois apontaram e anota cada correção. | Tudo. |

Verificador e leitor apressado são sempre novos a cada rodada, para não se acostumarem com a peça. O ciclo se repete até não sobrar número errado nem número sem a sua condição, no máximo três vezes.

## Os tipos de erro que a conferência procura

- **Número errado**: valor, unidade ou sinal diferentes do estudo.
- **Condição faltando ou trocada**: o número está certo, mas sem dizer em que cenário, rede, ano ou referência de preço ele vale.
- **Afirma mais do que a fonte**: o estudo diz "pode", a peça diz "vai".
- **Não está na fonte**: o estudo não diz aquilo.
- **Risco de citação** (do leitor apressado): a frase está certa no parágrafo, mas vira outra coisa numa manchete.

## Como rodar com o próximo estudo

Você vai precisar de um computador com Windows, o **Claude Code** instalado, o **Chrome**, o **Word** e o **PowerPoint**. A primeira vez, peça a alguém da equipe técnica para conferir se o Python e as bibliotecas da lista do fim estão instalados.

1. **Crie uma pasta para o caso** (por exemplo, `caso Novo Estudo`) e copie esta pasta `agente-lancamento` para dentro dela, sem mudar nada.
2. **Ponha os PDFs** numa subpasta chamada `fonte`.
3. **Abra o Claude Code** na pasta do caso.
4. **Peça o lançamento**, em português comum. Por exemplo:
   > Use a skill lancamento-de-estudo do agente-lancamento com os PDFs da pasta fonte. O estudo é sigiloso até a divulgação. Quero as sete peças de sempre. As tabelas que importam são a 2.1 (p. 30) e a 4.3 (p. 72). O rodapé é: "Protótipo feito com IA para formação. Não é material oficial do estudo. Fonte: ...".
5. **Responda às perguntas** que ele fizer antes de começar (sigilo, públicos, tabelas).
6. **Espere.** Um relatório de umas duzentas páginas, com sete peças, leva algumas horas e algumas dezenas de chamadas de subagentes. Os bastidores registram o tempo de cada etapa.
7. **Abra `saida/painel.html`** no navegador. Ele mostra as peças, o placar da conferência e os erros mais instrutivos.

## O que sai, e onde

| Arquivo | O que é |
|---|---|
| `saida/painel.html` | Página de entrada: peças, placar, erros pegos, como foi feito |
| `saida/ficha-evidencias.md` | A ficha do leitor (abre em qualquer editor de texto) |
| `saida/dados.json` | As tabelas copiadas do estudo, com as regras de leitura |
| `saida/*.docx`, `*.pptx`, `cards/` | As peças do kit |
| `saida/*.html` | As páginas interativas (abrem sem internet) |
| `saida/bastidores.md` | Tudo o que a conferência pegou, rodada a rodada, e quanto tempo levou |
| `saida/rastreabilidade.xlsx` | Uma linha por frase com número, com a página e o trecho do estudo |

## O que ele não faz

- Não publica nem envia nada. Tudo fica na pasta.
- Não usa logotipo nem cores de instituição.
- Não tira número de gráfico do PDF, só de texto e tabela.
- Não substitui a leitura de quem vai assinar o material. Os bastidores mostram onde a IA errou; leia-os antes de usar qualquer peça.

## Para a equipe técnica

- `CLAUDE.md`: regras das peças, fluxo e critério de parada.
- `.claude/agents/`: um arquivo por papel (leitor, redator, verificador, leitor-apressado, editor).
- `.claude/skills/lancamento-de-estudo/SKILL.md`: passo a passo para acionar o fluxo.
- `ferramentas/`: scripts genéricos (texto por página, montagem de Word, PowerPoint e cards, extração de texto para a conferência, capturas de tela, conferência de links, compilação dos bastidores, montagem do painel).
- Requisitos: Python 3.12 com pdfplumber, PyMuPDF, Pillow, python-docx, python-pptx, openpyxl e pywin32; Poppler (pdftotext); Chrome ou Edge; Word e PowerPoint.
