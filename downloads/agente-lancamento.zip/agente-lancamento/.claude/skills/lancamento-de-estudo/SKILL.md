---
name: lancamento-de-estudo
description: Roda o fluxo de lançamento de estudo (leitor, redatores, verificador, leitor apressado, editor) sobre um novo estudo em PDF e entrega o kit de comunicação, as páginas interativas, a rastreabilidade, os bastidores e o painel. Use quando alguém pedir para "lançar", "comunicar" ou "fazer o kit" de um relatório ou estudo.
---

# Lançamento de estudo

Siga o `CLAUDE.md` da pasta `agente-lancamento/` (regras das peças, fluxo e critério de parada). Esta skill diz como acionar o fluxo num estudo novo.

## 1. Antes de começar

Confirme com quem pediu, numa pergunta só, o que não estiver claro:

- onde estão os PDFs (relatório e, se houver, resumo executivo);
- se o material é sigiloso até a divulgação (se for: nada sai da máquina, nada de web, repositório só se for privado);
- quais peças e públicos (o padrão é o conjunto abaixo);
- quais tabelas devem ir para `dados.json` (número e página);
- o texto exato do rodapé de protótipo.

## 2. Montar o caso

1. Crie a pasta do caso, fora de `agente-lancamento/`, com `fonte/`, `scripts/` e `saida/`.
2. Copie os PDFs para `fonte/` sem renomear e registre o SHA256.
3. Gere o texto por página: `python agente-lancamento/ferramentas/paginas_pdf.py <pdf> <pasta> `.
4. Escreva `lancamento.json` na raiz do caso (veja o modelo abaixo).

```json
{
  "caso": "nome curto",
  "titulo_estudo": "...",
  "rodape": "Protótipo feito com IA para formação. Não é material oficial do estudo. Fonte: ...",
  "fontes": {"relatorio": {"arquivo": "fonte/...pdf", "paginas": 0, "sha256": "..."}},
  "tabelas": [{"id": "tabela_x_y", "nome": "Tabela X.Y", "pagina": 0}],
  "pecas": [{"id": "resumo-lideranca", "publico": "...", "formato": "docx", "arquivo": "saida/...", "tamanho": "uma página"}]
}
```

## 3. Rodar as etapas

Cada etapa é um subagente com o arquivo de papel em `.claude/agents/`. Ao lançar um subagente, entregue: o caminho do arquivo de papel, o `CLAUDE.md`, o `lancamento.json` e só os insumos que o papel permite (o verificador e o leitor apressado nunca recebem a ficha nem rodadas anteriores).

1. **Leitor**: ficha de evidências e `dados.json`. Rode a conferência da extração com um segundo extrator e um teste de mutação; não siga com divergência sem explicação.
2. **Redatores**: um por peça, todos no mesmo lote. Peças padrão:
   - resumo de uma página para liderança (docx);
   - brief de duas páginas para gestores da área (docx);
   - nota para imprensa com dez perguntas e respostas (docx);
   - seis cards para redes sociais (PNG 1080x1350 a partir de HTML);
   - apresentação de dez slides (pptx);
   - explorador de dados (HTML interativo, arquivo único, dados embutidos por script);
   - página-história de rolagem (HTML, arquivo único).
3. **Conferência**: para cada peça, rode `ferramentas/preparar_rodada.py <caso> <peça> <N>` (cria a pasta, extrai o texto da peça montada e diz se o critério de parada pede nova rodada), lance um verificador novo e um leitor apressado novo, depois o editor. Repita até o critério de parada do `CLAUDE.md` (no máximo três rodadas). Anote a hora de cada lote em `saida/conferencia/linha-do-tempo.jsonl`. Antes de dar a peça por encerrada, leia as decisões do editor (frase antes e depois): se ele marcou `mexeu_em_numero_ou_condicao = false` numa frase que ganhou número ou condição, reclassifique no próprio `editor.json` (guarde o valor declarado em `mexeu_declarado_pelo_editor` e explique em `revisao_do_orquestrador`) e abra a rodada seguinte. Na terceira rodada, o editor não mexe em número nem condição; o que exigiria isso vira pendência registrada.
4. **Registro**: gere `bastidores.md` e `rastreabilidade.xlsx` a partir dos JSON da conferência, por script.
5. **Painel e entrega**: escreva `painel.json` na pasta do caso (veja o cabeçalho de `ferramentas/montar_painel.py`), escolha os cinco erros mais instrutivos em `saida/conferencia/decisoes.json`, monte o painel, capture as telas (1366x768 e 390 px de largura, uma por aba e seção), confira links, abra o pptx no PowerPoint, converta os docx para PDF para conferir quebras, apague os PDFs de conferência, monte o zip e confira os links do zip extraído.

6. **Ajustes depois da entrega**: mudança de leiaute pedida depois da última rodada (gráfico novo, peça reorganizada) vai para `saida/conferencia/<peça>/rodada-ajuste/`: o orquestrador grava em `editor.json` o que mudou (quem pegou: `pedido_do_usuario`), e tudo o que mudou com número (frases e rótulos de gráfico) passa por um verificador novo, sem ficha e sem histórico. Uma versão nova de uma peça (por exemplo, cards leves com limite de palavras em `"regras"`) entra como peça nova em `lancamento.json` e faz as suas próprias rodadas.

## Ferramentas (pasta `ferramentas/`)

| Arquivo | Para quê |
|---|---|
| `paginas_pdf.py` | texto por página do PDF (pdftotext -layout, UTF-8) |
| `montar_docx.py` | Word a partir de texto marcado |
| `montar_pptx.py` | PowerPoint 16:9 a partir de texto marcado, com gráficos lidos de `dados.json` |
| `montar_cards.py` | cards HTML e PNG 1080x1350 pelo Chrome sem interface |
| `para_pdf.py` | Word/PowerPoint para PDF pelo Office (contagem de páginas e miniatura) |
| `texto_da_peca.py` | texto que o leitor vê na peça montada, para a conferência |
| `preparar_rodada.py` | cria a pasta da rodada, extrai o texto da peça e aplica o critério de parada |
| `capturas.py` | capturas de tela das páginas HTML por aba e seção |
| `checar_links.py` | links e recursos de páginas HTML (relativos, sem internet) |
| `compilar_conferencia.py` | bastidores, placar e rastreabilidade a partir dos JSON da conferência (aceita execução interrompida e retomada: eventos `interrupcao` e `retomada` na linha do tempo) |
| `montar_painel.py` | painel de entrada em arquivo único, com miniaturas embutidas; o que é do caso (frases do topo, títulos das peças, erros escolhidos) vai em `painel.json` na pasta do caso; `--pacote` gera a versão do zip |
| `montar_pacote.py` | zip para a equipe (painel do pacote, peças, rastreabilidade e a pasta do agente; sem PDFs da fonte nem prints), extraído numa pasta temporária para conferir os links, com SHA256 |
| `estilo.css` | estilo comum das peças HTML |

Requisitos: Python 3.12 com pdfplumber, PyMuPDF, Pillow, python-docx, python-pptx, openpyxl e pywin32; Poppler (pdftotext); Chrome ou Edge; Word e PowerPoint para a conferência visual.

Se o PowerPoint da pessoa estiver aberto, `para_pdf.py` usa a mesma instância (o PowerPoint só tem uma) e fecha só a cópia que abriu; nunca encerre processos do PowerPoint.
