"""Monta o painel de entrada (saida/painel.html): arquivo único, sem internet, com miniaturas embutidas.

Uso:
    python montar_painel.py <pasta_do_caso> [--pacote] [--saida <arquivo.html>]

Lê:
  lancamento.json                              peças (id, público, formato, arquivo, tamanho), rodapé
  painel.json (na pasta do caso)               o que é do caso: frases do estudo para o topo, texto
                                               "o que é esta vitrine", título e descrição de cada peça,
                                               quais peças vão em "Para explorar" e no "Kit", e os
                                               erros escolhidos como mais instrutivos (por peça, rodada
                                               e apontamento, com "trecho" opcional da frase antes para
                                               desempatar, e uma frase de "por que importa" sem número
                                               novo: o painel não passa pela conferência);
                                               opcionais: "legenda_ajuste" (frase a mais na legenda do
                                               placar) e "comparacao" (quadro "Completa ou leve?": peças
                                               "completa" e "leve" com cards de mesmo id e, por tema,
                                               "card", "tema", "cortou" e o apontamento do leitor
                                               apressado a citar em cada versão, {"rodada", "id"}; e
                                               "nota_rodada_final", frase com {n} que abre a lista das
                                               leituras erradas da versão leve fechadas numa rodada a mais)
  saida/conferencia/resumo-conferencia.json    placar, tempos e chamadas (de compilar_conferencia.py)
  saida/conferencia/decisoes.json              frase antes, frase depois e trecho da fonte
Gera as miniaturas na hora (Chrome sem interface para HTML; Word/PowerPoint para docx/pptx, via
para_pdf.py; os próprios PNG para cards) e apaga os PDFs intermediários.

--pacote: o link para o README do agente passa a ser "agente-lancamento/README.md", para o painel
que vai no zip ao lado da pasta agente-lancamento. Sem a opção, o link é "../agente-lancamento/README.md",
que é a posição do painel dentro de saida/ na pasta do caso.
Todos os outros links são relativos à pasta do painel.
"""
import base64
import html
import io
import json
import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
CHROME = [r"C:\Program Files\Google\Chrome\Application\chrome.exe",
          r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
          r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"]
NOMES_TIPO = {
    "numero_errado": "número errado",
    "condicao_faltando_ou_trocada": "condição faltando ou trocada",
    "afirma_mais_que_a_fonte": "afirma mais do que a fonte",
    "nao_esta_na_fonte": "não está na fonte",
    "risco_de_citacao": "risco de citação",
}
QUEM = {"verificador": "verificador", "leitor_apressado": "leitor apressado"}
FORMATO = {"docx": "Word", "pptx": "PowerPoint"}


def e(t):
    return html.escape(str(t if t is not None else ""))


def ler(p, padrao=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return padrao


def png_para_data_uri(png_bytes, largura=640):
    from PIL import Image
    im = Image.open(io.BytesIO(png_bytes)).convert("RGB")
    if im.width > largura:
        im = im.resize((largura, round(im.height * largura / im.width)), Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=82, optimize=True)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")


def foto_html(pagina, w=1366, h=768):
    chrome = next(c for c in CHROME if Path(c).exists())
    with tempfile.TemporaryDirectory() as tmp:
        png = Path(tmp) / "f.png"
        subprocess.run([chrome, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--force-device-scale-factor=1",
                        f"--window-size={w},{h}", f"--user-data-dir={Path(tmp) / 'perfil'}", "--virtual-time-budget=5000",
                        f"--screenshot={png}", Path(pagina).resolve().as_uri()], capture_output=True, timeout=180)
        return png.read_bytes()


def primeira_pagina_office(arquivo):
    """PNG da primeira página e número de páginas/slides, pelo Office (para_pdf.py). O PDF é apagado."""
    import fitz
    with tempfile.TemporaryDirectory() as tmp:
        pdf = Path(tmp) / "x.pdf"
        r = subprocess.run([sys.executable, "-I", str(AQUI / "para_pdf.py"), str(arquivo), str(pdf)],
                           capture_output=True, text=True, encoding="utf-8", errors="replace")
        if r.returncode != 0 or not pdf.exists():
            raise SystemExit(f"falha ao converter {arquivo}: {r.stderr.strip()[-400:]}")
        d = fitz.open(str(pdf))
        pg = d[0]
        zoom = 900 / pg.rect.width
        png = pg.get_pixmap(matrix=fitz.Matrix(zoom, zoom)).tobytes("png")
        n = d.page_count
        d.close()
    return png, n


def faixa_de_cards(pngs, largura=640):
    from PIL import Image
    ims = [Image.open(p).convert("RGB") for p in pngs[:3]]
    alt = 400
    ims = [im.resize((round(im.width * alt / im.height), alt), Image.LANCZOS) for im in ims]
    gap = 12
    tela = Image.new("RGB", (sum(i.width for i in ims) + gap * (len(ims) + 1), alt + 2 * gap), (241, 240, 236))
    x = gap
    for im in ims:
        tela.paste(im, (x, gap))
        x += im.width + gap
    buf = io.BytesIO()
    tela.save(buf, "PNG")
    return buf.getvalue()


def trecho_limpo(t):
    """Trecho literal para exibição: tira prefixos "Relatório p. 73:" e aspas externas que o editor
    às vezes grava, e junta vários trechos com [...]. O texto de cada trecho não muda."""
    import re
    partes = []
    for parte in str(t or "").split(" | "):
        parte = parte.strip()
        parte = re.sub(r'^\[?(Relat[óo]rio|Resumo)[^:"“]{0,25}:\s*', "", parte)
        parte = parte.strip().strip('"“”').strip()
        if parte:
            partes.append(f"“{parte}”")
    return " […] ".join(partes)


def tamanho_legivel(n):
    return f"{n / 1024:,.0f} KB".replace(",", ".") if n < 1024 * 1024 else f"{n / 1024 / 1024:,.1f} MB".replace(".", ",")


def minutos_legivel(m):
    if m is None:
        return "?"
    m = round(m)
    h, r = divmod(m, 60)
    return f"{m} min" if not h else f"{h} h {r:02d} min"


CSS = """
:root { color-scheme: light;
  --fundo:#f9f9f7; --superficie:#fcfcfb; --branco:#ffffff; --tinta:#0b0b0b; --tinta-2:#52514e; --tinta-3:#6b6a66;
  --grade:#e1e0d9; --eixo:#c3c2b7; --borda:rgba(11,11,11,.12); --libera:#2a78d6; --exige:#eb6834;
  --destaque-fundo:#eef3fa; --alerta-fundo:#fdf0e9; --ok:#0f7a52;
  --fonte: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; --raio:6px; }
html { font-size:18px; }
body { margin:0; background:var(--fundo); color:var(--tinta); font-family:var(--fonte); line-height:1.5; -webkit-font-smoothing:antialiased; }
main { max-width:1180px; margin:0 auto; padding:0 1rem; }
h1,h2,h3 { line-height:1.2; margin:0 0 .5em; font-weight:650; }
h1 { font-size:2rem; } h2 { font-size:1.5rem; margin-top:0; } h3 { font-size:1.1rem; }
p { margin:0 0 .8em; max-width:72ch; }
a { color:#1c5cab; }
a:focus-visible { outline:3px solid #1c5cab; outline-offset:2px; }
.topo { padding:2.2rem 0 1.4rem; border-bottom:1px solid var(--grade); }
.rotulo { font-size:.78rem; letter-spacing:.06em; text-transform:uppercase; color:var(--tinta-3); font-weight:600; margin-bottom:.4rem; }
.estudo-titulo { font-size:1rem; color:var(--tinta-2); margin-bottom:1rem; max-width:80ch; }
blockquote { margin:0 0 .6rem; padding:.2rem 0 .2rem 1rem; border-left:3px solid var(--eixo); font-size:1.12rem; max-width:75ch; }
.cita { font-size:.8rem; color:var(--tinta-3); margin:0 0 1.2rem; }
.vitrine { background:var(--destaque-fundo); border-radius:var(--raio); padding:1rem 1.2rem; max-width:none; }
.vitrine p { margin:0; max-width:90ch; }
section.bloco { padding:2rem 0 1rem; border-bottom:1px solid var(--grade); }
.sub { color:var(--tinta-2); margin-bottom:1.2rem; }
.grade-2 { display:grid; grid-template-columns:repeat(2, minmax(0,1fr)); gap:1.2rem; }
.grade-kit { display:grid; grid-template-columns:repeat(3, minmax(0,1fr)); gap:1.2rem; }
.cartao { background:var(--branco); border:1px solid var(--borda); border-radius:var(--raio); overflow:hidden; display:flex; flex-direction:column; }
.cartao .mini { display:block; background:#f1f0ec; border-bottom:1px solid var(--borda); aspect-ratio: 16 / 9; overflow:hidden; }
.cartao .mini img { width:100%; height:100%; object-fit:cover; object-position:top center; display:block; }
.cartao .mini.pagina img { object-fit:contain; background:#f1f0ec; }
.cartao .corpo { padding:.9rem 1rem 1rem; display:flex; flex-direction:column; gap:.35rem; flex:1; }
.cartao h3 { margin:0; }
.meta { font-size:.8rem; color:var(--tinta-3); }
.publico { font-size:.88rem; color:var(--tinta-2); }
.publico b { color:var(--tinta); font-weight:600; }
.conf { font-size:.8rem; color:var(--tinta-2); }
.conf .sim { color:var(--ok); font-weight:600; }
.conf .nao { color:#a3401a; font-weight:600; }
.acoes { margin-top:auto; padding-top:.5rem; display:flex; flex-wrap:wrap; gap:.5rem; }
.botao { display:inline-block; padding:.45rem .9rem; border-radius:var(--raio); background:#1c5cab; color:#fff; text-decoration:none; font-weight:600; font-size:.9rem; }
.botao.sec { background:var(--branco); color:#1c5cab; border:1px solid #1c5cab; }
.cards-mini { display:flex; gap:.35rem; flex-wrap:wrap; }
.cards-mini a { font-size:.8rem; }
.kpis { display:grid; grid-template-columns:repeat(5, minmax(0,1fr)); gap:1rem; margin-bottom:1.4rem; }
.kpi { background:var(--branco); border:1px solid var(--borda); border-radius:var(--raio); padding:.8rem 1rem; }
.kpi .v { font-size:1.9rem; font-weight:650; font-variant-numeric:tabular-nums; line-height:1.1; }
.kpi .r { font-size:.8rem; color:var(--tinta-2); }
.rolagem { overflow-x:auto; border:1px solid var(--borda); border-radius:var(--raio); background:var(--branco); }
table.placar { border-collapse:collapse; width:100%; font-size:.85rem; font-variant-numeric:tabular-nums; }
table.placar th, table.placar td { border-bottom:1px solid var(--grade); padding:.4rem .55rem; text-align:right; }
table.placar td.alerta { color:#a3401a; font-weight:600; }
table.placar td:last-child { min-width:8.5rem; }
table.placar th:first-child, table.placar td:first-child, table.placar th.esq, table.placar td.esq { text-align:left; }
table.placar thead th { color:var(--tinta-2); font-weight:600; border-bottom:1px solid var(--eixo); white-space:normal; vertical-align:bottom; }
table.placar td.trava { background:var(--alerta-fundo); font-weight:650; }
table.placar tr.nova-peca td { border-top:2px solid var(--eixo); }
.legenda { font-size:.8rem; color:var(--tinta-3); margin:.5rem 0 1.4rem; }
.erros { display:grid; gap:1rem; }
.erro { background:var(--branco); border:1px solid var(--borda); border-radius:var(--raio); padding:1rem 1.1rem; }
.erro .cab { font-size:.8rem; color:var(--tinta-3); margin-bottom:.5rem; }
.erro .cab b { color:var(--tinta); }
.par { display:grid; grid-template-columns:repeat(2, minmax(0,1fr)); gap:1rem; }
.antes, .depois { border-radius:var(--raio); padding:.6rem .8rem; font-size:.92rem; }
.antes { background:var(--alerta-fundo); }
.depois { background:#eaf5ef; }
.antes .r, .depois .r { display:block; font-size:.72rem; letter-spacing:.05em; text-transform:uppercase; color:var(--tinta-2); font-weight:600; margin-bottom:.2rem; }
.fonte { font-size:.85rem; color:var(--tinta-2); margin-top:.6rem; }
.porque { font-size:.88rem; margin-top:.5rem; }
.fluxo { display:flex; align-items:stretch; gap:.6rem; flex-wrap:nowrap; margin:1rem 0; }
.etapa { flex:1; background:var(--branco); border:1px solid var(--borda); border-radius:var(--raio); padding:.8rem .9rem; font-size:.85rem; }
.etapa h3 { font-size:1rem; margin:0 0 .3rem; }
.etapa .n { display:inline-block; width:1.6rem; height:1.6rem; border-radius:50%; background:#1c5cab; color:#fff; text-align:center; line-height:1.6rem; font-weight:650; font-size:.85rem; margin-right:.35rem; }
.etapa .ve { color:var(--tinta-3); font-size:.78rem; margin-top:.35rem; }
.par-conf { flex:1.4; display:flex; flex-direction:column; gap:.6rem; }
.seta { align-self:center; color:var(--tinta-3); font-size:1.4rem; }
.volta { font-size:.85rem; color:var(--tinta-2); border:1px dashed var(--eixo); border-radius:var(--raio); padding:.5rem .8rem; }
.comparar { display:grid; gap:1rem; margin-bottom:1.4rem; }
.comp { background:var(--branco); border:1px solid var(--borda); border-radius:var(--raio); padding:1rem 1.1rem; display:grid; grid-template-columns:minmax(0,1fr) minmax(0,1fr) minmax(0,1.5fr); gap:1rem; align-items:start; }
.comp figure { margin:0; }
.comp figure img { width:100%; height:auto; display:block; border:1px solid var(--borda); border-radius:4px; }
.comp figcaption { font-size:.78rem; color:var(--tinta-2); margin-top:.3rem; }
.comp h4 { margin:0 0 .4rem; font-size:1rem; }
.comp .bloco-txt { font-size:.88rem; display:flex; flex-direction:column; gap:.55rem; }
.comp .rot { display:block; font-size:.72rem; letter-spacing:.05em; text-transform:uppercase; color:var(--tinta-2); font-weight:600; }
.comp q { font-style:italic; }
.nota-comp { background:var(--branco); border:1px dashed var(--eixo); border-radius:var(--raio); padding:.8rem 1rem; font-size:.88rem; margin:-.4rem 0 1.4rem; }
.nota-comp p { margin:0 0 .4rem; }
.nota-comp ul { margin:0; padding-left:1.2rem; }
.nota-comp q { font-style:italic; }
.rodape-prototipo { font-size:.75rem; color:var(--tinta-2); border-top:1px solid var(--grade); padding:1rem 1rem 1.5rem; margin-top:2rem; max-width:1180px; margin-left:auto; margin-right:auto; }
@media (max-width: 900px) { .comp { grid-template-columns:repeat(2, minmax(0,1fr)); } .comp .bloco-txt { grid-column:1 / -1; } .grade-kit { grid-template-columns:repeat(2, minmax(0,1fr)); } .kpis { grid-template-columns:repeat(3, minmax(0,1fr)); } .fluxo { flex-direction:column; } .seta { transform:rotate(90deg); } }
@media (max-width: 600px) { html { font-size:16px; } h1 { font-size:1.6rem; } .grade-2, .grade-kit, .par { grid-template-columns:1fr; } .kpis { grid-template-columns:repeat(2, minmax(0,1fr)); } }
"""


def main():
    args = sys.argv[1:]
    if not args:
        raise SystemExit(__doc__)
    caso = Path(args[0]).resolve()
    pacote = "--pacote" in args
    destino = Path(args[args.index("--saida") + 1]).resolve() if "--saida" in args else caso / "saida" / "painel.html"
    cfg = ler(caso / "lancamento.json")
    pn = ler(caso / "painel.json")
    if pn is None:
        raise SystemExit("falta painel.json na pasta do caso")
    saida = caso / "saida"
    conf = ler(saida / "conferencia" / "resumo-conferencia.json", {})
    decisoes = ler(saida / "conferencia" / "decisoes.json", [])
    pecas = {p["id"]: p for p in cfg["pecas"]}
    readme = "agente-lancamento/README.md" if pacote else "../agente-lancamento/README.md"

    def rel(p):
        return Path(p).relative_to("saida").as_posix() if Path(p).parts[0] == "saida" else Path(p).as_posix()

    def estado_conf(pid):
        est = (conf.get("pecas") or {}).get(pid)
        if not est or not est.get("rodadas"):
            return '<div class="conf">Conferência: sem registro</div>'
        n = est["rodadas"]
        fin = " e na rodada final" if est.get("rodada_final") else ""
        pend = est.get("pendencias_abertas", 0)
        if pend:
            txt = f'<span class="nao">✗ {pend} pendência{"s" if pend > 1 else ""} em aberto</span>'
        elif est.get("zerou"):
            txt = '<span class="sim">✓ zerou</span> número errado e condição faltando, sem pendência'
        else:
            txt = '<span class="nao">✗ não zerou</span> número errado e condição faltando'
        return f'<div class="conf">Conferida em {n} rodada{"s" if n > 1 else ""}{fin} · {txt}</div>'

    # Miniaturas e tamanhos
    mini, detalhe = {}, {}
    for pid, p in pecas.items():
        arq = caso / p["arquivo"]
        fmt = p["formato"]
        if fmt.startswith("html"):
            mini[pid] = png_para_data_uri(foto_html(arq))
            detalhe[pid] = f"Página HTML · {tamanho_legivel(arq.stat().st_size)} · abre sem internet"
        elif fmt in ("docx", "pptx"):
            png, n = primeira_pagina_office(arq)
            mini[pid] = png_para_data_uri(png)
            un = "slide" if fmt == "pptx" else "página"
            detalhe[pid] = f"{FORMATO[fmt]} · {n} {un}{'s' if n > 1 else ''} · {tamanho_legivel(arq.stat().st_size)}"
        elif fmt.startswith("png"):
            pngs = sorted(arq.glob("*.png"))
            mini[pid] = png_para_data_uri(faixa_de_cards(pngs), 900)
            detalhe[pid] = f"{len(pngs)} imagens PNG 1080×1350 · {tamanho_legivel(sum(x.stat().st_size for x in pngs))}"
        print("miniatura", pid)

    def cartao(pid, grande=False):
        p = pecas[pid]
        info = pn["pecas"][pid]
        fmt = p["formato"]
        href = rel(p["arquivo"])
        classe_mini = "mini" if fmt.startswith("html") else "mini pagina"
        if fmt.startswith("html"):
            acoes = f'<a class="botao" href="{e(href)}">Abrir</a>'
            link_mini = href
        elif fmt.startswith("png"):
            pngs = sorted((caso / p["arquivo"]).glob("*.png"))
            links = " ".join(f'<a href="{e(rel(Path(p["arquivo"]) / x.name))}">{e(x.stem.replace("card-", "card "))}</a>' for x in pngs)
            acoes = f'<a class="botao" href="{e(rel(Path(p["arquivo"]) / pngs[0].name))}">Abrir o primeiro</a><div class="cards-mini">Abrir: {links}</div>'
            link_mini = rel(Path(p["arquivo"]) / pngs[0].name)
        else:
            acoes = f'<a class="botao" href="{e(href)}" download>Baixar .{fmt}</a>'
            link_mini = href
        return (f'<article class="cartao"><a class="{classe_mini}" href="{e(link_mini)}" aria-label="{e(info["titulo"])}">'
                f'<img src="{mini[pid]}" alt="Miniatura: {e(info["titulo"])}"></a>'
                f'<div class="corpo"><h3>{e(info["titulo"])}</h3>'
                f'<div class="publico"><b>Para:</b> {e(p["publico"])}</div>'
                f'<div>{e(info.get("descricao", ""))}</div>'
                f'<div class="meta">{e(detalhe[pid])}</div>{estado_conf(pid)}'
                f'<div class="acoes">{acoes}</div></div></article>')

    # Placar
    placar = conf.get("placar", [])
    tipos = ["numero_errado", "condicao_faltando_ou_trocada", "afirma_mais_que_a_fonte", "nao_esta_na_fonte"]
    linhas, anterior = [], None
    for l in placar:
        nova = ' class="nova-peca"' if anterior and l["peca"] != anterior else ""
        anterior = l["peca"]
        cel = []
        for t in tipos:
            v = l.get(t, 0)
            trava = t in ("numero_errado", "condicao_faltando_ou_trocada") and v
            cel.append(f'<td class="{"trava" if trava else ""}">{v}</td>')
        i_l = placar.index(l)
        tem_seguinte = i_l + 1 < len(placar) and placar[i_l + 1]["peca"] == l["peca"]
        seguinte = placar[i_l + 1]["rodada"] if tem_seguinte else None
        classe_sit = "esq"
        if l.get("zerou") is None:
            sit = "sem verificação"
        elif l["zerou"] and str(seguinte).startswith("final") and not str(l["rodada"]).startswith("final"):
            sit = "zerou · rodada final"
        elif l["zerou"] and seguinte == "ajuste de leiaute":
            sit = "zerou · ajuste de leiaute"
        elif l["zerou"] and tem_seguinte:
            sit = "zerou · nova rodada"
        elif l["zerou"] and ((conf.get("pecas") or {}).get(l["peca"]) or {}).get("pendencias_abertas"):
            sit, classe_sit = "zerou · pendência", "esq alerta"  # verificação zerada, mas ficou apontamento em aberto
        elif l["zerou"]:
            sit = "zerou"
        else:
            sit, classe_sit = ("nova rodada" if tem_seguinte else "não zerou · pendência"), "esq alerta"
        nome = pn["pecas"].get(l["peca"], {}).get("titulo", l["peca"])
        corr = "—" if l["rodada"] == "ajuste de leiaute" else l["corrigidos"]
        linhas.append(f'<tr{nova}><td class="esq">{e(nome)}</td><td>{e(l["rodada"])}</td><td>{l["frases_verificadas"]}</td>{"".join(cel)}'
                      f'<td>{l["apressado"]}</td><td>{corr}</td><td class="{classe_sit}">{sit}</td></tr>')
    tabela = ('<div class="rolagem"><table class="placar"><thead><tr><th>Peça</th><th>Rodada</th><th>Frases verificadas</th>'
              '<th>Número errado</th><th>Condição faltando ou trocada</th><th>Afirma mais do que a fonte</th><th>Não está na fonte</th>'
              '<th>Leitor apressado (risco de citação)</th><th>Correções do editor</th><th class="esq">Situação</th></tr></thead>'
              f'<tbody>{"".join(linhas)}</tbody></table></div>')

    tot = conf.get("totais_por_tipo", {})
    travas = tot.get("numero_errado", 0) + tot.get("condicao_faltando_ou_trocada", 0)
    frases = sum(l["frases_verificadas"] for l in placar)
    rodadas = len(placar)
    kpis = [
        (f"{frases:,}".replace(",", "."), "frases e números verificados contra o PDF, somando as rodadas"),
        (str(travas), "números errados ou sem a condição certa, pegos pelo verificador"),
        (str(sum(tot.get(t, 0) for t in ("afirma_mais_que_a_fonte", "nao_esta_na_fonte"))), "frases que afirmavam mais do que a fonte ou não estavam nela"),
        (str(conf.get("total_apressado", 0)), "frases que mudariam de sentido citadas sozinhas (leitor apressado)"),
        (str(conf.get("corrigidos", 0)), f"correções feitas pelo editor, em {rodadas} rodadas de conferência"),
    ]
    kpi_html = "".join(f'<div class="kpi"><div class="v">{v}</div><div class="r">{e(r)}</div></div>' for v, r in kpis)

    # Erros instrutivos
    erros = []
    for i, dz in enumerate(pn.get("destaques", []), 1):
        cand = [d for d in decisoes if d["peca"] == dz["peca"] and d["rodada"] == dz["rodada"]
                and d.get("apontamento") == dz["apontamento"] and d.get("decisao") == "corrigido"]
        if dz.get("trecho"):
            cand = [d for d in cand if dz["trecho"] in (d.get("frase_antes") or "")]
        if not cand:
            raise SystemExit(f"destaque não encontrado em decisoes.json: {dz}")
        d = cand[0]
        nome = pn["pecas"].get(d["peca"], {}).get("titulo", d["peca"])
        tipo = NOMES_TIPO.get(d.get("tipo_de_erro"), d.get("tipo_de_erro"))
        quem = QUEM.get(d.get("quem_pegou"), d.get("quem_pegou"))
        doc = {"relatorio": "Relatório", "resumo": "Resumo executivo"}.get(d.get("documento"), d.get("documento") or "")
        fonte = (f'<div class="fonte"><b>O que a fonte diz</b> ({e(doc)}, p. {e(d.get("pagina"))}): '
                 f'{e(trecho_limpo(d.get("trecho_da_fonte")))}</div>') if d.get("trecho_da_fonte") else ""
        depois = e(d.get("frase_depois")) or "<i>(frase cortada)</i>"
        erros.append(f'<article class="erro"><div class="cab"><b>{i}. {e(tipo).capitalize()}</b> · pego pelo {e(quem)} · '
                     f'{e(nome)}, rodada {d["rodada"]}</div>'
                     f'<div class="par"><div class="antes"><span class="r">Antes</span>{e(d.get("frase_antes"))}</div>'
                     f'<div class="depois"><span class="r">Depois</span>{depois}</div></div>{fonte}'
                     f'<div class="porque"><b>Por que importa:</b> {e(dz.get("por_que", ""))}</div></article>')

    # Tempo e chamadas
    t_total = conf.get("tempo_total_min")
    t_corrido = conf.get("tempo_corrido_min")
    cham = conf.get("chamadas_de_subagente", 0)
    desc = conf.get("chamadas_descartadas", 0)
    interr = conf.get("interrupcoes") or []
    tempo_txt = f"<b>{minutos_legivel(t_total)}</b> de trabalho do agente"
    pausas = conf.get("pausas") or []
    if interr or pausas:
        partes = []
        if interr:
            partes.append(f"a execução foi interrompida {'uma vez' if len(interr) == 1 else str(len(interr)) + ' vezes'} e retomada")
        if pausas:
            partes.append("houve uma pausa entre a primeira entrega e o fechamento das pendências" if len(pausas) == 1
                          else f"houve {len(pausas)} pausas entre entregas")
        tempo_txt += f" (somando só os trechos em que ele rodou; {' e '.join(partes)})"
    cham_txt = f"<b>{cham}</b> chamadas de subagente"
    if desc:
        cham_txt += f" (mais {desc} descartadas com a interrupção e refeitas)"
    etapas = conf.get("etapas", [])

    def soma(nome):
        return sum(x["minutos"] or 0 for x in etapas if x["etapa"] == nome)

    por_papel = " · ".join(f"{n}: {minutos_legivel(soma(n))}" for n in ("Leitor (ficha de evidências)", "Redator", "Verificador", "Leitor apressado", "Editor") if soma(n))

    comparar_html = ""
    cmp_cfg = pn.get("comparacao")
    if cmp_cfg:
        import re

        def apontamentos(pid, card):
            pasta = saida / "conferencia" / pid
            achados = []
            for r in sorted(pasta.glob("rodada-*")):
                a = ler(r / "apressado.json")
                if not a:
                    continue
                for it in a.get("itens", []):
                    if re.search(rf"\b{re.escape(card)}\b", it.get("onde_na_peca", "")):
                        achados.append((r.name.split("-", 1)[1], it))
            return achados

        def mini_card(pid, card):
            png = (caso / pecas[pid]["arquivo"] / f"{card}.png").read_bytes()
            return png_para_data_uri(png, 420), rel(Path(pecas[pid]["arquivo"]) / f"{card}.png")

        def apontou(pid, card, escolha):
            ach = apontamentos(pid, card)
            rodadas_peca = len([r for r in (saida / "conferencia" / pid).glob("rodada-*") if (r / "apressado.json").exists()])
            if not ach:
                return f"nenhum apontamento sobre este card em {rodadas_peca} rodada{'s' if rodadas_peca != 1 else ''}"
            txt = (f"{len(ach)} apontamento{'s' if len(ach) > 1 else ''} sobre este card em {rodadas_peca} "
                   f"rodada{'s' if rodadas_peca != 1 else ''}")
            sel = [it for (rd, it) in ach if escolha and rd == str(escolha.get("rodada")) and it.get("id") == escolha.get("id")]
            if escolha and not sel:
                raise SystemExit(f"apontamento do comparativo não encontrado: {pid} {card} {escolha}")
            if sel:
                txt += f". Na rodada {escolha['rodada']}, a leitura que ele temeu: <q>{e(sel[0].get('citada_sozinha', ''))}</q>"
            return txt

        blocos = []
        for tema in cmp_cfg["temas"]:
            card = tema["card"]
            uri_c, href_c = mini_card(cmp_cfg["completa"], card)
            uri_l, href_l = mini_card(cmp_cfg["leve"], card)
            tit_c = pn["pecas"][cmp_cfg["completa"]]["titulo"]
            tit_l = pn["pecas"][cmp_cfg["leve"]]["titulo"]
            blocos.append(
                f'<article class="comp">'
                f'<figure><a href="{e(href_c)}"><img src="{uri_c}" alt="{e(tit_c)}, {e(card)}"></a><figcaption>{e(tit_c)}</figcaption></figure>'
                f'<figure><a href="{e(href_l)}"><img src="{uri_l}" alt="{e(tit_l)}, {e(card)}"></a><figcaption>{e(tit_l)}</figcaption></figure>'
                f'<div class="bloco-txt"><h4>{e(tema["tema"])}</h4>'
                f'<div><span class="rot">O que a versão leve cortou</span>{e(tema["cortou"])}</div>'
                f'<div><span class="rot">Leitor apressado, versão completa</span>{apontou(cmp_cfg["completa"], card, tema.get("apressado_completa"))}</div>'
                f'<div><span class="rot">Leitor apressado, versão leve</span>{apontou(cmp_cfg["leve"], card, tema.get("apressado_leve"))}</div>'
                + (f'<div>{e(tema["nota"])}</div>' if tema.get("nota") else "") +
                f'</div></article>')
        nota_fin = ""
        if cmp_cfg.get("nota_rodada_final"):
            # Leituras erradas que ficaram como pendência na versão leve e foram fechadas numa rodada a mais.
            leve = cmp_cfg["leve"]
            lis = []
            for pf in conf.get("pendencias_fechadas", []):
                if pf["peca"] != leve or not isinstance(pf["rodada"], int):
                    continue  # só as pendências das rodadas numeradas, fechadas na rodada final
                a = ler(saida / "conferencia" / leve / f"rodada-{pf['rodada']}" / "apressado.json") or {}
                it = next((x for x in a.get("itens", []) if x.get("id") == pf["apontamento"]), None)
                if it:
                    onde = ", ".join(dict.fromkeys(re.findall(r"card-\d+", it.get("onde_na_peca", "")))).replace("card-", "card ")
                    lis.append(f'<li><b>{e(onde)}</b> (rodada {pf["rodada"]}): <q>{e(it.get("citada_sozinha", ""))}</q></li>')
            if lis:
                nota_fin = (f'<div class="nota-comp"><p>{e(cmp_cfg["nota_rodada_final"].format(n=len(lis)))}</p>'
                            f'<ul>{"".join(lis)}</ul></div>')
        comparar_html = (f'<h3 style="margin-top:1.4rem">{e(cmp_cfg.get("titulo", "Completa ou leve?"))}</h3>'
                         f'<p class="sub">{e(cmp_cfg.get("sub", ""))}</p><div class="comparar">{"".join(blocos)}</div>{nota_fin}')

    explorar = "".join(cartao(pid, True) for pid in pn["explorar"])
    kit = "".join(cartao(pid) for pid in pn["kit"])
    frases_estudo = "".join(f'<blockquote>“{e(f["texto"])}”</blockquote>' for f in pn["frases_do_estudo"])
    cita = "; ".join(sorted({f'{f["documento"]}, p. {f["pagina"]}' for f in pn["frases_do_estudo"]}))

    pagina = f"""<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{e(pn.get("titulo_pagina", "Painel de entrada"))}</title><style>{CSS}</style></head>
<body data-secoes="explorar,kit,conferencia,como">
<main>
<header class="topo">
  <h1>{e(pn.get("titulo", pn.get("titulo_pagina", "Painel de entrada")))}</h1>
  <div class="rotulo" style="margin-top:1.2rem">O estudo</div>
  <div class="estudo-titulo">{e(cfg.get("titulo_estudo", ""))}</div>
  {frases_estudo}
  <p class="cita">{e(cita)}</p>
  <div class="vitrine"><div class="rotulo">O que é esta vitrine</div><p>{e(pn["sobre_a_vitrine"])}</p></div>
</header>

<section class="bloco" id="explorar" aria-labelledby="h-explorar">
  <h2 id="h-explorar">Para explorar</h2>
  <p class="sub">{e(pn.get("sub_explorar", ""))}</p>
  <div class="grade-2">{explorar}</div>
</section>

<section class="bloco" id="kit" aria-labelledby="h-kit">
  <h2 id="h-kit">Kit de lançamento</h2>
  <p class="sub">{e(pn.get("sub_kit", ""))}</p>
  <div class="grade-kit">{kit}</div>
</section>

<section class="bloco" id="conferencia" aria-labelledby="h-conf">
  <h2 id="h-conf">O que a conferência pegou</h2>
  <p class="sub">{e(pn.get("sub_conferencia", ""))}</p>
  <div class="kpis">{kpi_html}</div>
  <h3>Placar de cada rodada</h3>
  {tabela}
  <p class="legenda">Fundo laranja: tipo de erro que obriga nova rodada (número errado e condição faltando ou trocada). A peça sai quando uma rodada zera esses dois tipos e o editor não mexe em número nem em condição; no máximo três rodadas. Na rodada final, um verificador novo conferiu só as pendências fechadas depois da terceira rodada e as frases mudadas depois da última verificação.{" " + e(pn["legenda_ajuste"]) if pn.get("legenda_ajuste") else ""} Cada frase com número, com a página e o trecho da fonte, está em <a href="rastreabilidade.xlsx" download>rastreabilidade.xlsx</a>.</p>
  {comparar_html}
  <h3>Os cinco erros mais instrutivos</h3>
  <div class="erros">{"".join(erros)}</div>
  <h3 style="margin-top:1.4rem">Quanto custou</h3>
  <p>{tempo_txt}; {cham_txt}.</p>
  <p class="meta">Tempo por papel, somando as peças e as rodadas (eles trabalham em paralelo, por isso a soma passa do total): {e(por_papel)}.</p>
</section>

<section class="bloco" id="como" aria-labelledby="h-como">
  <h2 id="h-como">Como foi feito</h2>
  <p class="sub">{e(pn.get("sub_como", ""))}</p>
  <div class="fluxo" role="list">
    <div class="etapa" role="listitem"><h3><span class="n">1</span>Leitor</h3>Lê o estudo inteiro e monta a ficha de evidências: cada achado com frase literal, página, número e condição. Copia as tabelas por programa e confere com um segundo programa.<div class="ve">Vê: o estudo inteiro</div></div>
    <div class="seta" aria-hidden="true">→</div>
    <div class="etapa" role="listitem"><h3><span class="n">2</span>Redatores</h3>Um por peça, todos ao mesmo tempo. Escrevem para o seu público só com a ficha e as tabelas.<div class="ve">Vê: ficha e tabelas, não o estudo</div></div>
    <div class="seta" aria-hidden="true">→</div>
    <div class="par-conf">
      <div class="etapa" role="listitem"><h3><span class="n">3</span>Verificador</h3>Procura cada frase e cada número da peça no PDF e diz se confere, com página e trecho, ou qual é o erro.<div class="ve">Vê: só a peça e o PDF. Novo a cada rodada</div></div>
      <div class="etapa" role="listitem"><h3><span class="n">4</span>Leitor apressado</h3>Lê como jornalista ou gestor com pressa e aponta a frase que, citada sozinha, muda o que o estudo diz.<div class="ve">Vê: só a peça e o PDF. Novo a cada rodada</div></div>
    </div>
    <div class="seta" aria-hidden="true">→</div>
    <div class="etapa" role="listitem"><h3><span class="n">5</span>Editor</h3>Corrige o que os dois apontaram, ou recusa citando a fonte, e registra cada decisão.<div class="ve">Vê: tudo</div></div>
  </div>
  <p class="volta">↺ A peça corrigida volta para um verificador e um leitor apressado novos até zerar número errado e condição faltando, no máximo três rodadas. Tudo fica registrado nos bastidores e na rastreabilidade.</p>
  <p>O agente é uma pasta que serve para o próximo estudo: <a href="{e(readme)}">leia o README do agente</a> (como rodar, em linguagem para quem não programa).</p>
</section>
</main>
<footer class="rodape-prototipo">{e(cfg["rodape"])}</footer>
</body></html>
"""
    destino.write_text(pagina, encoding="utf-8")
    print(f"ok {destino} {destino.stat().st_size:,} bytes".replace(",", "."))


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


if __name__ == "__main__":
    main()
