"""Capturas de tela de páginas HTML pelo Chrome sem interface, uma por aba e por seção.

Uso:
    python capturas.py <pagina.html> <pasta_saida> [larguraxaltura ...]

Tamanhos padrão: 1366x768 e 390x844. Larguras abaixo de 500 px e seções abertas por âncora (#id)
são capturadas dentro de uma moldura (iframe) do tamanho exato: o Chrome sem interface no Windows não
abre janela mais estreita que ~500 px, e fotografa em branco uma página que rolou pelo documento.
A página não precisa mudar por causa disso.
Estados capturados:
  - <body data-abas="a,b,c">     uma captura por aba, abrindo a página com #aba=<id>;
  - <body data-secoes="x,y,z">   uma captura por seção, abrindo a página com #<id>;
  - sem nenhum dos dois          uma captura do topo.
Também grava, para cada estado, um aviso se a página tiver rolagem horizontal ou
elementos de texto cortados (data-avisos no <body>, preenchido pelo script injetado
pela própria página, se existir).
"""
import re
import subprocess
import sys
import tempfile
from pathlib import Path

CHROME = [r"C:\Program Files\Google\Chrome\Application\chrome.exe",
          r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
          r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"]


def chrome():
    return next(c for c in CHROME if Path(c).exists())


def dump(url, w, h):
    with tempfile.TemporaryDirectory() as perfil:
        r = subprocess.run([chrome(), "--headless=new", "--disable-gpu", "--hide-scrollbars", f"--window-size={w},{h}",
                            f"--user-data-dir={perfil}", "--virtual-time-budget=5000", "--dump-dom", url],
                           capture_output=True, timeout=180)
    return r.stdout.decode("utf-8", "replace")


def foto(url, w, h, png):
    # Larguras estreitas e seções abertas por âncora (#id) são fotografadas numa moldura: o Chrome sem
    # interface fotografa em branco uma página que rolou pelo documento até a âncora.
    frag = url.split("#", 1)[1] if "#" in url else ""
    if w < 500 or (frag and not frag.startswith("aba=")):
        return foto_moldura(url, w, h, png)
    with tempfile.TemporaryDirectory() as perfil:
        subprocess.run([chrome(), "--headless=new", "--disable-gpu", "--hide-scrollbars", "--force-device-scale-factor=1",
                        f"--window-size={w},{h}", f"--user-data-dir={perfil}", "--virtual-time-budget=5000",
                        f"--screenshot={png}", url], capture_output=True, timeout=180)


def foto_moldura(url, w, h, png):
    from PIL import Image
    with tempfile.TemporaryDirectory() as tmp:
        moldura = Path(tmp) / "moldura.html"
        moldura.write_text(f'<!doctype html><html><body style="margin:0;background:#fff">'
                           f'<iframe src="{url}" style="width:{w}px;height:{h}px;border:0;display:block"></iframe>'
                           f'</body></html>', encoding="utf-8")
        bruto = Path(tmp) / "bruto.png"
        subprocess.run([chrome(), "--headless=new", "--disable-gpu", "--hide-scrollbars", "--force-device-scale-factor=1",
                        f"--window-size={max(w, 600)},{h}", f"--user-data-dir={Path(tmp) / 'perfil'}", "--virtual-time-budget=6000",
                        f"--screenshot={bruto}", moldura.as_uri()], capture_output=True, timeout=180)
        Image.open(bruto).crop((0, 0, w, h)).save(png)


def estados(dom):
    m = re.search(r'<body[^>]*data-abas="([^"]+)"', dom)
    if m:
        return [("aba-" + a.strip(), "#aba=" + a.strip()) for a in m.group(1).split(",")]
    m = re.search(r'<body[^>]*data-secoes="([^"]+)"', dom)
    if m:
        return [("secao-" + s.strip(), "#" + s.strip()) for s in m.group(1).split(",")]
    return [("topo", "")]


def main():
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    pagina = Path(sys.argv[1]).resolve()
    pasta = Path(sys.argv[2])
    pasta.mkdir(parents=True, exist_ok=True)
    tamanhos = [tuple(map(int, t.split("x"))) for t in sys.argv[3:]] or [(1366, 768), (390, 844)]
    base = pagina.as_uri()
    lista = estados(dump(base, 1366, 768))
    for w, h in tamanhos:
        for nome, frag in lista:
            png = pasta / f"{pagina.stem}_{nome}_{w}.png"
            foto(base + frag, w, h, png)
            if w < 500:
                print("ok", png.name, f"(moldura de {w} px; a autoconferência da página não é lida nessa largura)")
                continue
            dom = dump(base + frag, w, h)
            aviso = re.search(r'<body[^>]*data-avisos="([^"]*)"', dom)
            extra = f"  AVISOS: {aviso.group(1)}" if aviso and aviso.group(1) else ""
            print("ok", png.name + extra)


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


if __name__ == "__main__":
    main()
