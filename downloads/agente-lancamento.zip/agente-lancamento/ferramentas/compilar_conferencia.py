"""Junta os relatórios da conferência em bastidores, placar e rastreabilidade.

Uso:
    python compilar_conferencia.py <pasta_do_caso>

Lê:
  saida/conferencia/<peça>/redator.json
  saida/conferencia/<peça>/rodada-N/{verificador,apressado,editor}.json
  saida/conferencia/<peça>/rodada-final/      (depois da última rodada numerada: pendências fechadas e
                                               frases mudadas depois da última verificação)
  saida/conferencia/<peça>/rodada-ajuste/     (depois da final: ajustes de leiaute pedidos pelo usuário,
                                               editor.json com quem_pegou = "pedido_do_usuario"; uma decisão
                                               com "substitui_onde" tira da rastreabilidade as linhas antigas
                                               desses trechos da peça)
  saida/conferencia/linha-do-tempo.jsonl      (eventos do orquestrador: hora e nº de subagentes;
                                               "interrupcao" e "retomada" marcam uma execução
                                               interrompida: o tempo parado não entra no tempo ativo
                                               e "subagentes_descartados" conta à parte)
  saida/ficha-evidencias.md                   (hora de início e fim do leitor, no comentário do topo)
  lancamento.json
Grava:
  saida/bastidores.md
  saida/conferencia/resumo-conferencia.json   (placar e tempos, para o painel)
  saida/rastreabilidade.xlsx                  (uma linha por frase com número, de todas as peças)
Nada do placar é digitado: tudo sai dos JSON.
"""
import datetime as dt
import json
import re
import sys
from collections import Counter, OrderedDict
from pathlib import Path

TIPOS = ["numero_errado", "condicao_faltando_ou_trocada", "afirma_mais_que_a_fonte", "nao_esta_na_fonte"]
NOMES_TIPO = {
    "confere": "confere",
    "numero_errado": "número errado",
    "condicao_faltando_ou_trocada": "condição faltando ou trocada",
    "afirma_mais_que_a_fonte": "afirma mais do que a fonte",
    "nao_esta_na_fonte": "não está na fonte",
    "sem_conteudo_factual": "sem conteúdo factual",
    "risco_de_citacao": "risco de citação (leitor apressado)",
    "ajuste_de_leiaute": "ajuste de leiaute (pedido do usuário)",
    "contraponto_faltando": "contraponto que faltava (revisão do usuário)",
    "pendencia": "pendência fechada",
}
TRAVAM = {"numero_errado", "condicao_faltando_ou_trocada"}


def hora(t):
    if not t:
        return None
    t = str(t).strip().replace("Z", "+00:00")
    t = re.sub(r"(\.\d{6})\d+", r"\1", t)
    try:
        h = dt.datetime.fromisoformat(t)
    except ValueError:
        return None
    if h.tzinfo is None:
        h = h.replace(tzinfo=dt.timezone(dt.timedelta(hours=-3)))
    return h


def minutos(a, b):
    a, b = hora(a), hora(b)
    if not a or not b:
        return None
    return round((b - a).total_seconds() / 60, 1)


def ler(p):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return None


def norm(s):
    return re.sub(r"\s+", " ", str(s or "").replace(" ", " ")).strip()


def normaliza_classe(c):
    c = (c or "").strip().lower()
    c = c.replace(" ", "_").replace("í", "i").replace("ã", "a").replace("ç", "c").replace("ú", "u").replace("é", "e")
    apelidos = {"condicao_faltando": "condicao_faltando_ou_trocada", "condicao_trocada": "condicao_faltando_ou_trocada",
                "afirma_mais_do_que_a_fonte": "afirma_mais_que_a_fonte", "nao_esta_na_fonte": "nao_esta_na_fonte"}
    return apelidos.get(c, c)


def main():
    caso = Path(sys.argv[1]).resolve()
    saida = caso / "saida"
    conf = saida / "conferencia"
    cfg = json.loads((caso / "lancamento.json").read_text(encoding="utf-8"))
    pecas = [p["id"] for p in cfg["pecas"]]

    eventos = []
    lt = conf / "linha-do-tempo.jsonl"
    if lt.exists():
        eventos = [json.loads(l) for l in lt.read_text(encoding="utf-8").splitlines() if l.strip()]
    chamadas = sum(int(e.get("subagentes", 0)) for e in eventos)
    descartadas = sum(int(e.get("subagentes_descartados", 0)) for e in eventos)
    ini_tarefa = next((e["hora"] for e in eventos if e["evento"] == "inicio_tarefa"), None)
    fim_tarefa = next((e["hora"] for e in reversed(eventos) if e["evento"] == "fim_tarefa"), None) or (eventos[-1]["hora"] if eventos else None)
    # Trechos ativos: do início até cada interrupção e de cada retomada até a próxima interrupção ou o fim.
    trechos, aberto = [], ini_tarefa
    for e in eventos:
        if e["evento"] in ("interrupcao", "pausa") and aberto:
            trechos.append((aberto, e["hora"]))
            aberto = None
        elif e["evento"] == "retomada":
            aberto = e["hora"]
    if aberto and fim_tarefa:
        trechos.append((aberto, fim_tarefa))
    tempo_ativo = round(sum(m for m in (minutos(a, b) for a, b in trechos) if m), 1) if trechos else None
    interrupcoes = [e for e in eventos if e["evento"] == "interrupcao"]
    pausas = [e for e in eventos if e["evento"] == "pausa"]

    ficha = (saida / "ficha-evidencias.md").read_text(encoding="utf-8") if (saida / "ficha-evidencias.md").exists() else ""
    m_ini = re.search(r"in[ií]cio:\s*([0-9T:\-.+Z]+)", ficha)
    m_fim = re.search(r"fim:\s*([0-9T:\-.+Z]+)", ficha)
    etapas = [{"etapa": "Leitor (ficha de evidências)", "peca": "-", "rodada": "-",
               "inicio": m_ini.group(1) if m_ini else None, "fim": m_fim.group(1) if m_fim else None}]

    placar = []          # uma linha por peça e rodada
    decisoes = []        # todas as decisões do editor
    rastreio = []        # frases com número, última rodada
    dados_embutidos = [] # valores de tabela embutidos em páginas interativas, conferidos por script
    estado = OrderedDict()
    for peca in pecas:
        d = conf / peca
        red = ler(d / "redator.json")
        if red:
            etapas.append({"etapa": "Redator", "peca": peca, "rodada": "-", "inicio": red.get("inicio"), "fim": red.get("fim")})
        def ordem(p):
            s = p.name.split("-", 1)[1]
            if s.isdigit():
                return int(s)
            if re.fullmatch(r"final-\d+", s):  # nova rodada final depois de um ajuste de leiaute
                return 920 + int(s.split("-")[1])
            return {"final": 900, "ajuste": 920}.get(s, 999)
        rodadas = sorted((p for p in d.glob("rodada-*") if p.is_dir()), key=ordem)
        ultima_verif = None
        verifs = []
        for r in rodadas:
            s = r.name.split("-", 1)[1]
            n = int(s) if s.isdigit() else {"ajuste": "ajuste de leiaute"}.get(s, s.replace("-", " "))
            v = ler(r / "verificador.json")
            a = ler(r / "apressado.json")
            e = ler(r / "editor.json")
            cont = Counter()
            if v:
                for it in v.get("itens", []):
                    cont[normaliza_classe(it.get("classificacao"))] += 1
                etapas.append({"etapa": "Verificador", "peca": peca, "rodada": n, "inicio": v.get("inicio"), "fim": v.get("fim")})
                ultima_verif = (n, v)
                verifs.append((n, v, r))
            n_apr = len(a.get("itens", [])) if a else 0
            if a:
                etapas.append({"etapa": "Leitor apressado", "peca": peca, "rodada": n, "inicio": a.get("inicio"), "fim": a.get("fim")})
            if e:
                etapas.append({"etapa": "Editor", "peca": peca, "rodada": n, "inicio": e.get("inicio"), "fim": e.get("fim")})
                for dec in e.get("decisoes", []):
                    dd = dict(dec)
                    dd["peca"] = peca
                    dd["rodada"] = n
                    dd["tipo_de_erro"] = normaliza_classe(dd.get("tipo_de_erro"))
                    decisoes.append(dd)
            linha = {"peca": peca, "rodada": n, "frases_verificadas": sum(cont.values()), "confere": cont.get("confere", 0),
                     "apressado": n_apr}
            for t in TIPOS:
                linha[t] = cont.get(t, 0)
            linha["sem_conteudo_factual"] = cont.get("sem_conteudo_factual", 0)
            linha["zerou"] = all(cont.get(t, 0) == 0 for t in TRAVAM) if v else None
            linha["corrigidos"] = sum(1 for dd in (e or {}).get("decisoes", []) if dd.get("decisao") == "corrigido")
            linha["recusados"] = sum(1 for dd in (e or {}).get("decisoes", []) if dd.get("decisao") == "recusado")
            placar.append(linha)
        num = [x for x in verifs if isinstance(x[0], int)]
        pos = [x for x in verifs if not isinstance(x[0], int)]  # rodadas depois da última numerada, em ordem
        sequencia = ([num[-1]] if num else []) + pos
        if num:
            n0 = num[-1][0]
            vps = ler(d / f"rodada-{n0}" / "valores-por-script.json")
            if vps:
                for it in (vps if isinstance(vps, list) else vps.get("valores", [])):
                    dados_embutidos.append({"peca": peca, "rodada": n0, **{k: it.get(k, "") for k in
                                            ("tabela", "linha", "coluna", "valor_na_peca", "pagina", "linha_do_pdf", "classificacao")}})

        def bate(frase, antes):
            for seg in str(antes or "").split(" / "):
                seg = re.sub(r"^\[[^\]]*\]\s*", "", seg.strip())
                if frase and seg and (frase == seg or (len(frase) >= 25 and frase in seg) or (len(seg) >= 25 and seg in frase)):
                    return True
            return False

        def decs_de(rdir):
            return (ler(rdir / "editor.json") or {}).get("decisoes", [])

        txt_ult = ""
        if sequencia and (sequencia[-1][2] / "texto-da-peca.txt").exists():
            txt_ult = norm((sequencia[-1][2] / "texto-da-peca.txt").read_text(encoding="utf-8"))
        for i, (n, v, rdir) in enumerate(sequencia):
            depois = sequencia[i + 1:]
            decs_post = [dd for (_, _, rr) in depois for dd in decs_de(rr)]
            # Nas rodadas numeradas, o editor mexe depois do verificador; nas posteriores, as decisões vêm antes.
            # Nas rodadas posteriores, só contam as decisões tomadas depois da verificação da própria rodada.
            decs_seg = (decs_de(rdir) if isinstance(n, int) else
                        [dd for dd in decs_de(rdir) if dd.get("depois_da_verificacao")]) + decs_post
            if any((ler(rr / "frases-alteradas.json") or {}).get("peca_inteira") for (_, _, rr) in depois):
                continue  # uma rodada posterior conferiu a peça inteira de novo
            if any(dd.get("onde_na_peca") == "peça inteira" and dd.get("decisao") == "corrigido" for dd in decs_post):
                continue  # a peça inteira foi reorganizada e conferida de novo numa rodada posterior
            # Uma decisão posterior pode substituir um trecho inteiro da peça (campo substitui_onde, prefixos de onde_na_peca):
            # as linhas antigas desse trecho saem e entram as da rodada que conferiu a versão nova.
            subst = [s for dd in decs_post if dd.get("decisao") == "corrigido" for s in dd.get("substitui_onde", [])]
            subst += [s for (_, _, rr) in depois for s in (ler(rr / "frases-alteradas.json") or {}).get("substitui_onde", [])]
            for it in v.get("itens", []):
                if not it.get("tem_numero"):
                    continue
                if any(str(it.get("onde_na_peca", "")).startswith(s) for s in subst):
                    continue
                frase = it.get("frase", "")
                f_it = norm(frase)
                dep = ""
                for dd in decs_seg:
                    if dd.get("decisao") == "mantido" and dep:
                        continue  # "mantido" não apaga uma correção ou pendência já encontrada
                    if bate(frase, dd.get("frase_antes")):
                        dep = ("corrigida pelo editor depois desta verificação: " + (dd.get("frase_depois") or "(cortada)")
                               if dd.get("decisao") == "corrigido" else
                               "apontamento mantido sem mudança: " + (dd.get("motivo") or "")
                               if dd.get("decisao") == "mantido" else
                               "apontamento recusado pelo editor (pendência): " + (dd.get("motivo") or ""))
                        if dd.get("decisao") == "corrigido":
                            break
                if depois:
                    if dep.startswith("corrigida"):
                        continue  # a versão nova desta frase foi conferida numa rodada posterior
                    if dep.startswith("apontamento recusado"):
                        ampliada = any(dd.get("decisao") == "corrigido" and (
                            (f_it in norm(dd.get("frase_depois")) and f_it != norm(dd.get("frase_depois")))
                            or (len(norm(dd.get("frase_antes"))) >= 25 and norm(dd.get("frase_antes")) in f_it))
                            for dd in decs_post)
                        if ampliada or (txt_ult and f_it not in txt_ult):
                            continue
                        dep = "pendência sobre esta frase fechada depois (a correção, numa frase vizinha, foi conferida na rodada seguinte)"
                if i > 0 and not dep:
                    dep = ("frase alterada depois da última rodada numerada e conferida na "
                           + (f"rodada {n}" if str(n).startswith("final") else f"rodada de {n}"))
                rastreio.append({"peca": peca, "rodada": n, "onde": it.get("onde_na_peca", ""), "frase": frase, "depois": dep,
                                 "documento": it.get("documento", ""), "pagina": it.get("pagina", ""),
                                 "trecho": it.get("trecho_literal", ""),
                                 "classificacao": NOMES_TIPO.get(normaliza_classe(it.get("classificacao")), it.get("classificacao", ""))})
        linhas_peca = [l for l in placar if l["peca"] == peca]
        estado[peca] = {"rodadas": len([l for l in linhas_peca if isinstance(l["rodada"], int)]),
                        "rodada_final": any(str(l["rodada"]).startswith("final") for l in linhas_peca),
                        "ajuste": any(l["rodada"] == "ajuste de leiaute" for l in linhas_peca),
                        "zerou": bool(linhas_peca and linhas_peca[-1]["zerou"])}

    # Pendências: recusas que nenhuma decisão posterior fechou (campo fecha_pendencia).
    fechadas = {(d["peca"], f.get("rodada"), f.get("apontamento")) for d in decisoes if d.get("decisao") == "corrigido"
                for f in d.get("fecha_pendencia", [])}
    recusas = [d for d in decisoes if d.get("decisao") == "recusado"]
    abertas = [d for d in recusas if (d["peca"], d["rodada"], d.get("apontamento")) not in fechadas]
    for peca, est in estado.items():
        est["pendencias_abertas"] = sum(1 for d in abertas if d["peca"] == peca)
        est["zerou_verificacao"] = est["zerou"]
        est["zerou"] = est["zerou"] and est["pendencias_abertas"] == 0

    for et in etapas:
        et["minutos"] = minutos(et["inicio"], et["fim"])

    resumo = {
        "gerado_em": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "inicio_tarefa": ini_tarefa, "fim_tarefa": fim_tarefa,
        "tempo_total_min": tempo_ativo if (interrupcoes or pausas) else minutos(ini_tarefa, fim_tarefa),
        "tempo_corrido_min": minutos(ini_tarefa, fim_tarefa),
        "trechos_ativos": [{"inicio": a, "fim": b, "minutos": minutos(a, b)} for a, b in trechos],
        "interrupcoes": interrupcoes,
        "pausas": pausas,
        "chamadas_de_subagente": chamadas,
        "chamadas_descartadas": descartadas,
        "pecas": estado, "placar": placar, "etapas": etapas,
        "totais_por_tipo": {t: sum(l[t] for l in placar) for t in TIPOS},
        "total_apressado": sum(l["apressado"] for l in placar),
        "decisoes": len([d for d in decisoes if d.get("quem_pegou") != "pedido_do_usuario"]),
        "ajustes_de_leiaute": sum(1 for d in decisoes if d.get("quem_pegou") == "pedido_do_usuario"),
        "corrigidos": sum(1 for d in decisoes if d.get("decisao") == "corrigido" and d.get("quem_pegou") != "pedido_do_usuario"),
        "corrigidos_por_apontamento": sum(1 for d in decisoes if d.get("decisao") == "corrigido"
                                          and d.get("quem_pegou") in ("verificador", "leitor_apressado")),
        "recusados": sum(1 for d in decisoes if d.get("decisao") == "recusado"),
        "pendencias": [{"peca": d["peca"], "rodada": d["rodada"], "apontamento": d.get("apontamento"),
                        "frase": d.get("frase_antes"), "motivo": d.get("motivo")} for d in abertas],
        "pendencias_fechadas": [{"peca": d["peca"], "rodada": d["rodada"], "apontamento": d.get("apontamento"),
                                 "frase": d.get("frase_antes")} for d in recusas if d not in abertas],
    }
    (conf / "resumo-conferencia.json").write_text(json.dumps(resumo, ensure_ascii=False, indent=1), encoding="utf-8")
    (conf / "decisoes.json").write_text(json.dumps(decisoes, ensure_ascii=False, indent=1), encoding="utf-8")

    # bastidores.md
    md = ["# Bastidores da conferência", "",
          f"Gerado por `agente-lancamento/ferramentas/compilar_conferencia.py` em {resumo['gerado_em']}, a partir dos relatórios em `saida/conferencia/`.", "",
          "## Resumo", "",
          (f"- Tempo ativo da tarefa: {resumo['tempo_total_min']} min, somando os trechos em que ela rodou "
           f"(de {ini_tarefa} a {fim_tarefa} passaram {resumo['tempo_corrido_min']} min de relógio, com a parada)"
           if (interrupcoes or pausas) else f"- Tempo total da tarefa: {resumo['tempo_total_min']} min ({ini_tarefa} a {fim_tarefa})"),
          f"- Chamadas de subagente: {chamadas}" + (f" (mais {descartadas} descartadas na execução interrompida)" if descartadas else ""),
          f"- Apontamentos do verificador que travam a peça (número errado + condição faltando ou trocada), somando todas as rodadas: "
          f"{resumo['totais_por_tipo']['numero_errado'] + resumo['totais_por_tipo']['condicao_faltando_ou_trocada']}",
          f"- Decisões do editor: {resumo['decisoes']} ({resumo['corrigidos']} correções, {resumo['recusados']} recusas)"]
    if resumo["ajustes_de_leiaute"]:
        md.append(f"- Ajustes de leiaute pedidos pelo usuário: {resumo['ajustes_de_leiaute']}, conferidos por um verificador novo (ver abaixo)")
    md += ["", "| Peça | Rodadas | Rodada final | Ajuste de leiaute | Zerou número errado e condição na última verificação? | Pendências em aberto |",
           "|---|---|---|---|---|---|"]
    for p, e in estado.items():
        md.append(f"| {p} | {e['rodadas']} | {'sim' if e.get('rodada_final') else 'não'} | {'sim' if e.get('ajuste') else 'não'} | "
                  f"{'sim' if e['zerou_verificacao'] else 'NÃO'} | {e['pendencias_abertas']} |")
    if interrupcoes:
        md += ["", "## Interrupção", ""]
        for e in interrupcoes:
            md.append(f"- {e['hora']}: {e.get('nota', 'execução interrompida')}")
        md += ["", "Os tempos anteriores à interrupção são parciais. Trechos em que a tarefa rodou:", ""]
        for tr in resumo["trechos_ativos"]:
            md.append(f"- {tr['inicio']} a {tr['fim']}: {tr['minutos']} min")
    if pausas:
        md += ["", "## Pausas", ""]
        for e in pausas:
            md.append(f"- {e['hora']}: {e.get('nota', 'pausa')}")
    if any(e.get("rodada_final") for e in estado.values()):
        md += ["", "## Rodada final", "",
               "Depois das três rodadas, as pendências e as frases alteradas depois da última verificação passaram por um "
               "verificador novo, sem ficha e sem histórico (pastas `rodada-final`). Elas aparecem com a rodada \"final\" no placar, "
               "nos tempos e na lista de correções. Quando a peça muda de novo depois de uma rodada final ou de um ajuste, a nova "
               "verificação vai para `rodada-final-2` (\"final 2\" no placar); com `\"peca_inteira\": true` em frases-alteradas.json, "
               "a rastreabilidade da peça passa a sair inteira dessa rodada."]
    if any(e.get("ajuste") for e in estado.values()):
        md += ["", "## Ajuste de leiaute", "",
               "Depois da rodada final, o usuário pediu ajustes de leiaute (gráficos da apresentação, resumo para a liderança reorganizado). "
               "Tudo o que mudou com número, frases e rótulos de gráfico, passou por um verificador novo, sem ficha e sem histórico, contra os PDFs "
               "(pastas `rodada-ajuste`). Os ajustes aparecem com a rodada \"ajuste de leiaute\" no placar, nos tempos e na lista de correções, "
               "com quem pegou = pedido do usuário."]
    md += ["", "## Placar por rodada", "",
           "| Peça | Rodada | Frases verificadas | Confere | Número errado | Condição faltando ou trocada | Afirma mais | Não está na fonte | Leitor apressado | Correções | Recusas |",
           "|---|---|---|---|---|---|---|---|---|---|---|"]
    for l in placar:
        md.append(f"| {l['peca']} | {l['rodada']} | {l['frases_verificadas']} | {l['confere']} | {l['numero_errado']} | "
                  f"{l['condicao_faltando_ou_trocada']} | {l['afirma_mais_que_a_fonte']} | {l['nao_esta_na_fonte']} | {l['apressado']} | "
                  f"{l['corrigidos']} | {l['recusados']} |")
    md += ["", "## Tempo de cada etapa", "", "| Etapa | Peça | Rodada | Início | Fim | Minutos |", "|---|---|---|---|---|---|"]
    for et in etapas:
        md.append(f"| {et['etapa']} | {et['peca']} | {et['rodada']} | {et['inicio'] or '?'} | {et['fim'] or '?'} | {et['minutos'] if et['minutos'] is not None else '?'} |")
    if eventos:
        md += ["", "## Linha do tempo do orquestrador", "", "| Hora | Evento | Subagentes | Nota |", "|---|---|---|---|"]
        for e in eventos:
            md.append(f"| {e['hora']} | {e['evento']} | {e.get('subagentes', '')} | {e.get('nota', '')} |")
    md += ["", "## O que foi corrigido, frase por frase", ""]

    def cel(t):
        return str(t or "").replace("|", "/").replace("\n", " ")

    for peca in pecas:
        dp = [d for d in decisoes if d["peca"] == peca]
        if not dp:
            continue
        md += [f"### {peca}", "", "| Rodada | Quem pegou | Tipo de erro | Decisão | Frase antes | Frase depois | Fonte | Motivo |", "|---|---|---|---|---|---|---|---|"]
        for d in dp:
            fonte = f"{d.get('documento', '')} p. {d.get('pagina', '')}: \"{cel(d.get('trecho_da_fonte'))}\"" if d.get("pagina") else ""
            md.append(f"| {d['rodada']} | {cel(d.get('quem_pegou'))} | {NOMES_TIPO.get(d['tipo_de_erro'], d['tipo_de_erro'])} | {cel(d.get('decisao'))} | "
                      f"{cel(d.get('frase_antes'))} | {cel(d.get('frase_depois')) or '(cortada)'} | {fonte} | {cel(d.get('motivo'))}" + (f" **Revisão do orquestrador:** {cel(d.get('revisao_do_orquestrador'))}" if d.get('revisao_do_orquestrador') else "") + " |")
        md.append("")
    if resumo["pendencias_fechadas"]:
        md += ["## Pendências fechadas na rodada final", "", "| Peça | Rodada da recusa | Apontamento | Frase antes |", "|---|---|---|---|"]
        for pd in resumo["pendencias_fechadas"]:
            md.append(f"| {pd['peca']} | {pd['rodada']} | {cel(pd['apontamento'])} | {cel(pd['frase'])} |")
        md.append("")
    md += ["## Pendências em aberto", "",
           "Apontamentos recusados que nenhuma correção posterior fechou, com o motivo.", ""]
    if resumo["pendencias"]:
        md += ["| Peça | Rodada | Apontamento | Frase | Motivo |", "|---|---|---|---|---|"]
        for pd in resumo["pendencias"]:
            md.append(f"| {pd['peca']} | {pd['rodada']} | {cel(pd['apontamento'])} | {cel(pd['frase'])} | {cel(pd['motivo'])} |")
    else:
        md.append("Nenhuma.")
    nao = [p for p, e in estado.items() if e["rodadas"] and not e["zerou"]]
    if nao:
        md += ["", "Peças que não zeraram número errado e condição faltando na última verificação ou têm pendência em aberto: " + ", ".join(nao) + "."]
    md.append("")
    (saida / "bastidores.md").write_text("\n".join(md) + "\n", encoding="utf-8")

    # rastreabilidade.xlsx
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "Frases com número"
    cab = ["Peça", "Onde na peça", "Frase", "Documento", "Página", "Trecho literal da fonte", "Classificação final",
           "Rodada da verificação", "Depois da última verificação"]
    ws.append(cab)
    for r in rastreio:
        ws.append([r["peca"], r["onde"], r["frase"], r["documento"], r["pagina"], r["trecho"], r["classificacao"], r["rodada"], r["depois"]])
    larguras = [18, 22, 60, 11, 8, 70, 24, 10, 50]
    for i, w in enumerate(larguras, 1):
        ws.column_dimensions[ws.cell(1, i).column_letter].width = w
    for c in ws[1]:
        c.font = Font(bold=True)
        c.fill = PatternFill("solid", fgColor="F1F0EC")
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    if dados_embutidos:
        ws3 = wb.create_sheet("Dados embutidos")
        ws3.append(["Peça", "Tabela", "Linha", "Coluna", "Valor na peça", "Página", "Linha do PDF (pdftotext)", "Classificação", "Rodada"])
        for r in dados_embutidos:
            ws3.append([r["peca"], r["tabela"], str(r["linha"]), r["coluna"], str(r["valor_na_peca"]), r["pagina"],
                        r["linha_do_pdf"], NOMES_TIPO.get(normaliza_classe(r["classificacao"]), r["classificacao"]), r["rodada"]])
        for c in ws3[1]:
            c.font = Font(bold=True)
            c.fill = PatternFill("solid", fgColor="F1F0EC")
        for i, w in enumerate([18, 12, 26, 26, 12, 8, 90, 16, 8], 1):
            ws3.column_dimensions[ws3.cell(1, i).column_letter].width = w
        ws3.freeze_panes = "A2"
        ws3.auto_filter.ref = ws3.dimensions
    ws2 = wb.create_sheet("Leia-me")
    ws2.append(["Uma linha por frase com número, de todas as peças, com a classificação da verificação mais recente daquela frase: "
                "a última rodada numerada da peça ou, para frases alteradas depois dela, a rodada final ou a de ajuste de leiaute. "
                "A última coluna diz se a frase mudou depois da verificação ou se houve um apontamento recusado sobre ela."])
    ws2.append(["Gerado por agente-lancamento/ferramentas/compilar_conferencia.py a partir de saida/conferencia/<peça>/rodada-N/verificador.json."])
    ws2.append([cfg.get("rodape", "")])
    ws2.column_dimensions["A"].width = 140
    wb.save(saida / "rastreabilidade.xlsx")
    print(f"ok: {len(placar)} linhas de placar, {len(decisoes)} decisões, {len(rastreio)} frases com número, {chamadas} chamadas")


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


if __name__ == "__main__":
    main()
