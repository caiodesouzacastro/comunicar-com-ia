"""Gera um arquivo de texto por página de um PDF, com pdftotext -layout (UTF-8).

Uso:
    python paginas_pdf.py <arquivo.pdf> <pasta_de_saida> [prefixo]

Cria <pasta_de_saida>/<prefixo>p001.txt, p002.txt... e <prefixo>completo.txt.
O pdftotext do Poppler não abre caminhos com acento no Windows, por isso o PDF
é copiado antes para uma pasta temporária com nome simples.
"""
import os
import shutil
import subprocess
import sys
import tempfile


def numero_de_paginas(pdf):
    saida = subprocess.run(["pdfinfo", pdf], capture_output=True, text=True, encoding="utf-8", errors="replace").stdout
    for linha in saida.splitlines():
        if linha.startswith("Pages:"):
            return int(linha.split()[1])
    raise SystemExit("pdfinfo não informou o número de páginas")


def main():
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    origem, destino = sys.argv[1], sys.argv[2]
    prefixo = sys.argv[3] if len(sys.argv) > 3 else ""
    os.makedirs(destino, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        pdf = os.path.join(tmp, "doc.pdf")
        shutil.copyfile(origem, pdf)
        n = numero_de_paginas(pdf)
        largura = max(3, len(str(n)))
        for i in range(1, n + 1):
            alvo = os.path.join(tmp, "p.txt")
            subprocess.run(["pdftotext", "-enc", "UTF-8", "-layout", "-f", str(i), "-l", str(i), pdf, alvo], check=True)
            shutil.copyfile(alvo, os.path.join(destino, f"{prefixo}p{i:0{largura}d}.txt"))
        alvo = os.path.join(tmp, "c.txt")
        subprocess.run(["pdftotext", "-enc", "UTF-8", "-layout", pdf, alvo], check=True)
        shutil.copyfile(alvo, os.path.join(destino, f"{prefixo}completo.txt"))
    print(f"{n} páginas -> {destino}")


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


if __name__ == "__main__":
    main()
