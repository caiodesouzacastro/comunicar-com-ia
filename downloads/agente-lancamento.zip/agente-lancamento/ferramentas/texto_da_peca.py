"""Extrai o texto que o leitor vê numa peça montada, para o verificador e o leitor apressado.

Uso:
    python texto_da_peca.py <peça> <saida.txt>

<peça> pode ser:
  .docx  parágrafos e tabelas na ordem, mais o rodapé
  .pptx  slide a slide: caixas de texto (de cima para baixo), tabelas e notas do apresentador
  .html  texto da página depois de o JavaScript rodar (Chrome sem interface). Se o <body>
         tiver data-abas="a,b,c", extrai uma vez por aba, abrindo a página com #aba=<id>.
  pasta  todos os .html da pasta (cards), um depois do outro
  .md    o próprio texto (peças escritas em Markdown, como versões de referência com citações)
"""
import re
import subprocess
import sys
import tempfile
from html.parser import HTMLParser
from pathlib import Path

CHROME = [r"C:\Program Files\Google\Chrome\Application\chrome.exe",
          r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
          r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"]


def de_docx(p):
    from docx import Document
    d = Document(p)
    out = []
    corpo = d.element.body
    for el in corpo.iterchildren():
        tag = el.tag.split("}")[1]
        if tag == "p":
            t = "".join(x.text or "" for x in el.iter() if x.tag.endswith("}t"))
            if t.strip():
                out.append(t.strip())
        elif tag == "tbl":
            out.append("[tabela]")
            for tr in el.iter():
                if tr.tag.endswith("}tr"):
                    cel = []
                    for tc in tr.iterchildren():
                        if tc.tag.endswith("}tc"):
                            cel.append("".join(x.text or "" for x in tc.iter() if x.tag.endswith("}t")).strip())
                    out.append(" | ".join(cel))
            out.append("[fim da tabela]")
    for s in d.sections:
        rod = " ".join(p.text for p in s.footer.paragraphs if p.text.strip())
        if rod:
            out.append("[rodapé] " + rod)
            break
    return "\n".join(out)


def de_pptx(p):
    from pptx import Presentation
    prs = Presentation(p)
    out = []
    for i, s in enumerate(prs.slides, 1):
        out.append(f"=== Slide {i}")
        formas = sorted(s.shapes, key=lambda sh: (sh.top or 0, sh.left or 0))
        for sh in formas:
            if sh.has_text_frame:
                t = "\n".join(par.text for par in sh.text_frame.paragraphs if par.text.strip())
                if t.strip():
                    out.append(t)
            if getattr(sh, "has_table", False) and sh.has_table:
                for r in sh.table.rows:
                    out.append(" | ".join(c.text for c in r.cells))
        if s.has_notes_slide:
            n = s.notes_slide.notes_text_frame.text.strip()
            if n:
                out.append("[notas] " + n)
    return "\n".join(out)


class Texto(HTMLParser):
    BLOCO = {"p", "div", "li", "h1", "h2", "h3", "h4", "tr", "section", "figcaption", "caption", "br", "td", "th", "button", "option", "label", "summary", "text", "tspan", "title", "desc"}

    def __init__(self):
        super().__init__()
        self.partes = []
        self.pular = 0
        self.abas = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "body" and a.get("data-abas"):
            self.abas = a["data-abas"].split(",")
        if tag in ("script", "style"):
            self.pular += 1
        if tag in self.BLOCO:
            self.partes.append("\n")
        if tag in ("td", "th"):
            self.partes.append(" | ")

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self.pular -= 1
        if tag in self.BLOCO:
            self.partes.append("\n")

    def handle_data(self, data):
        if not self.pular:
            self.partes.append(data)

    def texto(self):
        t = "".join(self.partes)
        t = re.sub(r"[ \t\r\f\v]+", " ", t)
        t = re.sub(r"\n\s*\n+", "\n", t)
        return t.strip()


def dom(url, largura=1366):
    chrome = next(c for c in CHROME if Path(c).exists())
    with tempfile.TemporaryDirectory() as perfil:
        r = subprocess.run([chrome, "--headless=new", "--disable-gpu", f"--window-size={largura},900",
                            f"--user-data-dir={perfil}", "--virtual-time-budget=4000", "--dump-dom", url],
                           capture_output=True, timeout=180)
    return r.stdout.decode("utf-8", "replace")


def de_html(p):
    base = Path(p).resolve().as_uri()
    t = Texto()
    t.feed(dom(base))
    if not t.abas:
        return t.texto()
    out = []
    for aba in t.abas:
        t2 = Texto()
        t2.feed(dom(base + "#aba=" + aba.strip()))
        out.append(f"=== Aba {aba.strip()}\n" + t2.texto())
    return "\n".join(out)


def main():
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    p = Path(sys.argv[1])
    if p.is_dir():
        texto = "\n".join(f"=== {h.name}\n" + de_html(h) for h in sorted(p.glob("*.html")))
    elif p.suffix.lower() == ".docx":
        texto = de_docx(p)
    elif p.suffix.lower() == ".pptx":
        texto = de_pptx(p)
    elif p.suffix.lower() in (".html", ".htm"):
        texto = de_html(p)
    elif p.suffix.lower() in (".md", ".txt"):
        texto = p.read_text(encoding="utf-8").strip()
    else:
        raise SystemExit("formato não suportado")
    Path(sys.argv[2]).write_text(texto + "\n", encoding="utf-8")
    print("ok", sys.argv[2], len(texto), "caracteres")


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


if __name__ == "__main__":
    main()
