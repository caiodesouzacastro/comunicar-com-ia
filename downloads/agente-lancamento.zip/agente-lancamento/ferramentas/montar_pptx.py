"""Monta um .pptx sóbrio (16:9, sem modelo institucional) a partir de texto simples.

Uso:
    python montar_pptx.py <entrada.md> <saida.pptx> <lancamento.json> <dados.json>

Um slide por bloco; blocos separados por uma linha com '---'. Em cada bloco:
    # Título do slide
    texto                         parágrafo
    - item                        lista
    > texto                       linha de condição / de onde vem (pequena, cinza, embaixo)
    notas: texto                  notas do apresentador (podem continuar nas linhas seguintes)
    @numero {"valor": "R$ 12,3 bilhões", "rotulo": "texto curto embaixo do número"}
    @grafico {...}                gráfico desenhado com formas, valores lidos de dados.json:
        {"tipo": "barras", "tabela": "tabela_x_y", "chave": "categoria",
         "linhas": ["Linha A (rótulo como na fonte)", ...], "nomes": ["A", ...],
         "coluna": "coluna_valor", "titulo": "...", "sinal": true,
         "negativo": "libera", "positivo": "exige", "sufixo": "",
         "filtro": {"cenario": "Cenário B"}}   (filtro: opcional, fixa outras chaves da linha)
        {"tipo": "anos", "tabela": "tabela_x_z", "cenario": "Cenário A",
         "coluna": "valor_rs_bi", "titulo": "...", "sinal": true}
            (a tabela precisa ter linhas com as chaves "cenario" e "ano")
        {"tipo": "linhas", "tabela": "tabela_x_w", "colunas": ["grupo_a", ...],
         "nomes": ["Grupo A", ...], "titulo": "..."}
        {"tipo": "halteres", "tabela": "tabela_x_y", "chave": "categoria", "linhas": [...], "nomes": [...],
         "de": "coluna_inicial", "para": "coluna_final", "rotulo_de": "2019", "rotulo_para": "2040", "titulo": "..."}
            (um haltere por linha: ponto cinza no valor inicial, ponto escuro no final (o azul fica reservado para "libera"), os dois rotulados)
    @corpo 24                     tamanho fixo do corpo (pt) neste slide; sem ele, 20 pt, descendo até 18 se não couber
Com "sinal": true, a barra negativa é azul e rotulada com "negativo" (padrão "libera"),
a positiva é laranja e rotulada com "positivo" (padrão "exige"); o número aparece sem sinal.
O rodapé de protótipo de lancamento.json vai em todos os slides.
"""
import json
import re
import sys

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Inches, Pt

TINTA = RGBColor(0x0B, 0x0B, 0x0B)
TINTA2 = RGBColor(0x52, 0x51, 0x4E)
TINTA3 = RGBColor(0x6B, 0x6A, 0x66)
GRADE = RGBColor(0xE1, 0xE0, 0xD9)
EIXO = RGBColor(0xC3, 0xC2, 0xB7)
LIBERA = RGBColor(0x2A, 0x78, 0xD6)
EXIGE = RGBColor(0xEB, 0x68, 0x34)
NEUTRO = RGBColor(0x8F, 0x8E, 0x88)
CATEG = [RGBColor(0x2A, 0x78, 0xD6), RGBColor(0xEB, 0x68, 0x34), RGBColor(0x1B, 0xAF, 0x7A),
         RGBColor(0xED, 0xA1, 0x00), RGBColor(0xE8, 0x7B, 0xA4)]
FUNDO = RGBColor(0xFC, 0xFC, 0xFB)
FONTE = "Calibri"
W, H = Inches(13.333), Inches(7.5)


def caixa(slide, x, y, w, h, texto="", tam=18, cor=TINTA, negrito=False, alinh=PP_ALIGN.LEFT, ancora=MSO_ANCHOR.TOP):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Inches(0.04)
    tf.margin_top = tf.margin_bottom = Inches(0.02)
    tf.vertical_anchor = ancora
    if texto:
        par(tf.paragraphs[0], texto, tam, cor, negrito, alinh)
    return tf


def par(p, texto, tam, cor=TINTA, negrito=False, alinh=PP_ALIGN.LEFT):
    p.alignment = alinh
    for pedaco in re.split(r"(\*\*[^*]+\*\*)", texto):
        if not pedaco:
            continue
        b = negrito
        if pedaco.startswith("**") and pedaco.endswith("**"):
            pedaco, b = pedaco[2:-2], True
        r = p.add_run()
        r.text = pedaco
        r.font.size = Pt(tam)
        r.font.name = FONTE
        r.font.bold = b
        r.font.color.rgb = cor


def retangulo(slide, x, y, w, h, cor):
    s = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, max(w, Emu(1)), max(h, Emu(1)))
    s.fill.solid()
    s.fill.fore_color.rgb = cor
    s.line.fill.background()
    s.shadow.inherit = False
    return s


def linha(slide, x1, y1, x2, y2, cor, larg=1.0):
    """Linha horizontal ou vertical desenhada como retângulo fino (sem sombra do tema)."""
    e = int(Pt(larg))
    if y1 == y2:
        return retangulo(slide, min(x1, x2), y1 - e // 2, abs(x2 - x1), e, cor)
    return retangulo(slide, x1 - e // 2, min(y1, y2), e, abs(y2 - y1), cor)


def celula(tabela, chaves):
    for l in tabela["linhas"]:
        if all(str(l.get(k)) == str(v) for k, v in chaves.items()):
            return l
    raise SystemExit(f"linha não encontrada em {tabela['nome']}: {chaves}")


def sem_sinal(t):
    return t[1:] if t.startswith("-") else t


def zero_na_fonte(v):
    """Valor que a fonte mostra como zero (ex.: -0,0): não libera nem exige."""
    return all(ch in "-0,." for ch in v["t"])


def rotulo_valor(g, v, sep=" "):
    if g.get("sinal") and zero_na_fonte(v):
        return "zero" + sep + v["t"].lstrip("-")
    if g.get("sinal"):
        neg = v["v"] < 0
        return (g.get("negativo", "libera") if neg else g.get("positivo", "exige")) + sep + sem_sinal(v["t"]) + g.get("sufixo", "")
    return v["t"] + g.get("sufixo", "")


def grafico_barras(slide, g, dados, x, y, w, h):
    tab = dados["tabelas"][g["tabela"]]
    nomes = g.get("nomes", g["linhas"])
    vals = [celula(tab, {**g.get("filtro", {}), g["chave"]: l})["valores"][g["coluna"]] for l in g["linhas"]]
    caixa(slide, x, y, w, Inches(0.45), g.get("titulo", ""), 15, TINTA2, True)
    y0 = y + Inches(0.6)
    altura = h - Inches(0.65)
    n = len(vals)
    passo = altura / n
    larg_rot = Inches(1.9)
    larg_val = Inches(1.55)
    tem_neg = any(v["v"] < 0 for v in vals)
    tem_pos = any(v["v"] > 0 for v in vals)
    area_x = x + larg_rot + (larg_val if tem_neg else 0)
    area_w = w - larg_rot - (larg_val if tem_neg else 0) - (larg_val if tem_pos else 0)
    vmin = min(0, min(v["v"] for v in vals))
    vmax = max(0, max(v["v"] for v in vals))
    escala = area_w / (vmax - vmin if vmax > vmin else 1)
    zero_x = area_x + int(-vmin * escala)
    for i, (nome, v) in enumerate(zip(nomes, vals)):
        yy = y0 + int(passo * i)
        bh = int(min(passo * 0.62, Inches(0.55)))
        caixa(slide, x, yy, larg_rot - Inches(0.12), bh, nome, 14, TINTA, alinh=PP_ALIGN.RIGHT, ancora=MSO_ANCHOR.MIDDLE)
        comp = int(abs(v["v"]) * escala)
        neg = v["v"] < 0
        cor = (LIBERA if neg else EXIGE) if g.get("sinal") else CATEG[0]
        bx = zero_x - comp if neg else zero_x
        retangulo(slide, bx, yy, comp, bh, cor)
        lx = (bx - larg_val) if neg else (bx + comp + Inches(0.06))
        caixa(slide, lx, yy, larg_val - Inches(0.06), bh, rotulo_valor(g, v), 13, TINTA,
              alinh=PP_ALIGN.RIGHT if neg else PP_ALIGN.LEFT, ancora=MSO_ANCHOR.MIDDLE)
    linha(slide, zero_x, y0 - Inches(0.05), zero_x, y0 + int(passo * (n - 1)) + int(min(passo * 0.62, Inches(0.55))) + Inches(0.05), EIXO, 1.25)


def grafico_anos(slide, g, dados, x, y, w, h):
    tab = dados["tabelas"][g["tabela"]]
    linhas = [l for l in tab["linhas"] if l["cenario"] == g["cenario"]]
    vals = [l["valores"][g["coluna"]] for l in linhas]
    anos = [l["ano"] for l in linhas]
    caixa(slide, x, y, w, Inches(0.45), g.get("titulo", ""), 15, TINTA2, True)
    esp_rot = Inches(0.52)
    esp_ano = Inches(0.36)
    vmin = min(0, min(v["v"] for v in vals))
    vmax = max(0, max(v["v"] for v in vals))
    topo = y + Inches(0.5) + (esp_rot if vmax > 0 else 0)
    base = y + h - esp_ano - (esp_rot if vmin < 0 else 0)
    escala = (base - topo) / (vmax - vmin if vmax > vmin else 1)
    zero_y = topo + int(vmax * escala)
    n = len(vals)
    passo = w / n
    for i, (ano, v) in enumerate(zip(anos, vals)):
        xx = x + int(passo * i) + int(passo * 0.2)
        bw = int(passo * 0.6)
        comp = int(abs(v["v"]) * escala)
        neg = v["v"] < 0
        cor = (LIBERA if neg else EXIGE) if g.get("sinal") else CATEG[0]
        by = zero_y if neg else zero_y - comp
        retangulo(slide, xx, by, bw, comp, cor)
        ly = (by + comp + Inches(0.02)) if neg else (by - esp_rot)
        tf = caixa(slide, xx - Inches(0.25), ly, bw + Inches(0.5), esp_rot, "", 12, ancora=MSO_ANCHOR.TOP if neg else MSO_ANCHOR.BOTTOM)
        for k, pedaco in enumerate(rotulo_valor(g, v, "\n").split("\n")):
            p = tf.paragraphs[0] if k == 0 else tf.add_paragraph()
            par(p, pedaco, 12, TINTA, False, PP_ALIGN.CENTER)
        caixa(slide, xx - Inches(0.2), y + h - esp_ano, bw + Inches(0.4), esp_ano, str(ano), 13, TINTA2, alinh=PP_ALIGN.CENTER)
    linha(slide, x, zero_y, x + w, zero_y, EIXO, 1.25)


def ponto(slide, cx, cy, diam, cor):
    s = slide.shapes.add_shape(MSO_SHAPE.OVAL, cx - diam // 2, cy - diam // 2, diam, diam)
    s.fill.solid()
    s.fill.fore_color.rgb = cor
    s.line.fill.background()
    s.shadow.inherit = False
    return s


def grafico_halteres(slide, g, dados, x, y, w, h):
    tab = dados["tabelas"][g["tabela"]]
    nomes = g.get("nomes", g["linhas"])
    pares = [celula(tab, {**g.get("filtro", {}), g["chave"]: l})["valores"] for l in g["linhas"]]
    de = [v[g["de"]] for v in pares]
    para = [v[g["para"]] for v in pares]
    caixa(slide, x, y, w, Inches(0.45), g.get("titulo", ""), 15, TINTA2, True)
    # legenda
    ly = y + Inches(0.5)
    ponto(slide, x + Inches(0.1), ly + Inches(0.14), Inches(0.14), NEUTRO)
    caixa(slide, x + Inches(0.22), ly, Inches(2.6), Inches(0.3), g.get("rotulo_de", g["de"]), 12, TINTA2)
    ponto(slide, x + Inches(2.9), ly + Inches(0.14), Inches(0.14), TINTA)
    caixa(slide, x + Inches(3.02), ly, w - Inches(3.02), Inches(0.3), g.get("rotulo_para", g["para"]), 12, TINTA2)
    y0 = y + Inches(1.0)
    altura = h - Inches(1.05)
    n = len(pares)
    passo = altura / n
    larg_rot = Inches(1.45)
    area_x = x + larg_rot + Inches(0.55)
    area_w = w - larg_rot - Inches(1.1)
    vmax = max(max(v["v"] for v in de), max(v["v"] for v in para))
    escala = area_w / (vmax if vmax > 0 else 1)
    diam = Inches(0.17)
    for i, (nome, a, b) in enumerate(zip(nomes, de, para)):
        cy = y0 + int(passo * i) + int(passo / 2)
        caixa(slide, x, cy - Inches(0.2), larg_rot, Inches(0.4), nome, 14, TINTA, alinh=PP_ALIGN.RIGHT, ancora=MSO_ANCHOR.MIDDLE)
        xa = area_x + int(a["v"] * escala)
        xb = area_x + int(b["v"] * escala)
        linha(slide, min(xa, xb), cy, max(xa, xb), cy, GRADE, 3.0)
        ponto(slide, xa, cy, diam, NEUTRO)
        ponto(slide, xb, cy, diam, TINTA)
        esq, dir_ = (a, b) if a["v"] <= b["v"] else (b, a)
        x_esq, x_dir = min(xa, xb), max(xa, xb)
        caixa(slide, x_esq - Inches(0.75), cy - Inches(0.18), Inches(0.62), Inches(0.36), esq["t"], 12, TINTA,
              alinh=PP_ALIGN.RIGHT, ancora=MSO_ANCHOR.MIDDLE)
        caixa(slide, x_dir + Inches(0.13), cy - Inches(0.18), Inches(0.62), Inches(0.36), dir_["t"], 12, TINTA,
              ancora=MSO_ANCHOR.MIDDLE)


def grafico_linhas(slide, g, dados, x, y, w, h):
    tab = dados["tabelas"][g["tabela"]]
    anos = [l["ano"] for l in tab["linhas"]]
    caixa(slide, x, y, w, Inches(0.45), g.get("titulo", ""), 15, TINTA2, True)
    y0 = y + Inches(0.6)
    area_w = w - Inches(2.5)
    altura = h - Inches(1.1)
    todos = [l["valores"][c]["v"] for l in tab["linhas"] for c in g["colunas"]]
    vmax = max(todos) * 1.08
    a0, a1 = min(anos), max(anos)
    def px(ano): return x + int((ano - a0) / (a1 - a0) * area_w)
    def py(v): return y0 + int((1 - v / vmax) * altura)
    linha(slide, x, py(0), x + area_w, py(0), EIXO, 1.0)
    for ano in anos:
        caixa(slide, px(ano) - Inches(0.35), py(0) + Inches(0.05), Inches(0.7), Inches(0.3), str(ano), 12, TINTA2, alinh=PP_ALIGN.CENTER)
    finais = []
    for k, (col, nome) in enumerate(zip(g["colunas"], g.get("nomes", g["colunas"]))):
        pts = [(px(l["ano"]), py(l["valores"][col]["v"])) for l in tab["linhas"]]
        fb = slide.shapes.build_freeform(pts[0][0], pts[0][1], scale=1.0)
        fb.add_line_segments(pts[1:], close=False)
        s = fb.convert_to_shape()
        s.fill.background()
        s.shadow.inherit = False
        s.line.color.rgb = CATEG[k % len(CATEG)]
        s.line.width = Pt(2.5)
        finais.append([pts[-1][1], f"{nome} {tab['linhas'][-1]['valores'][col]['t']} em {anos[-1]}", CATEG[k % len(CATEG)]])
    # afasta rótulos finais que se encostam (mínimo 0,3 pol. entre centros)
    finais.sort(key=lambda f: f[0])
    minimo = Inches(0.3)
    for i in range(1, len(finais)):
        if finais[i][0] - finais[i - 1][0] < minimo:
            finais[i][0] = finais[i - 1][0] + minimo
    for yc, rot, cor in finais:
        retangulo(slide, x + area_w + Inches(0.08), yc - Inches(0.04), Inches(0.08), Inches(0.08), cor)
        caixa(slide, x + area_w + Inches(0.2), yc - Inches(0.16), Inches(2.4), Inches(0.32), rot, 12, TINTA, ancora=MSO_ANCHOR.MIDDLE)


def numero(slide, n, x, y, w, h):
    tf = caixa(slide, x, y + Inches(0.6), w, Inches(1.5), "", 60)
    par(tf.paragraphs[0], n["valor"], 60, TINTA, True)
    tf2 = caixa(slide, x, y + Inches(2.2), w, Inches(1.6), "", 20)
    par(tf2.paragraphs[0], n.get("rotulo", ""), 20, TINTA2)


def montar(entrada, saida, cfg, dados):
    texto = open(entrada, encoding="utf-8").read()
    blocos = [b.strip("\n") for b in re.split(r"^---\s*$", texto, flags=re.M) if b.strip()]
    prs = Presentation()
    prs.slide_width, prs.slide_height = W, H
    branco = prs.slide_layouts[6]
    for b in blocos:
        s = prs.slides.add_slide(branco)
        bg = s.background.fill
        bg.solid()
        bg.fore_color.rgb = FUNDO
        titulo, corpo, conds, notas, visual, corpo_fixo = "", [], [], [], None, None
        em_notas = False
        for l in b.splitlines():
            if l.startswith("<!--"):
                continue
            if l.startswith("# "):
                titulo = l[2:].strip(); em_notas = False
            elif l.startswith("notas:"):
                notas.append(l[6:].strip()); em_notas = True
            elif em_notas:
                notas.append(l.strip())
            elif l.startswith("> "):
                conds.append(l[2:].strip())
            elif l.startswith("@numero "):
                visual = ("numero", json.loads(l[8:]))
            elif l.startswith("@grafico "):
                visual = ("grafico", json.loads(l[9:]))
            elif l.startswith("@corpo "):
                corpo_fixo = float(l[7:].strip())
            elif l.strip():
                corpo.append(l.rstrip())
        caixa(s, Inches(0.6), Inches(0.4), Inches(12.1), Inches(1.1), titulo, 32, TINTA, True, ancora=MSO_ANCHOR.BOTTOM)
        linha(s, Inches(0.6), Inches(1.6), Inches(12.7), Inches(1.6), GRADE, 1.0)
        tx, tw = Inches(0.6), Inches(12.1)
        if visual:
            tw = Inches(4.9)
        if corpo:
            # Corpo em 20 pt; se a estimativa de linhas não couber na caixa, desce até 18 pt (mínimo em slide).
            import math
            larg_pt, alt_pt = tw / 12700, 4.1 * 72
            tam = 20
            for tam in ((corpo_fixo,) if corpo_fixo else (20, 19, 18)):
                cpl = max(1, int(larg_pt / (tam * 0.5)))
                linhas_est = sum(max(1, math.ceil(len(l) / cpl)) for l in corpo)
                if linhas_est * tam * 1.2 + 10 * len(corpo) <= alt_pt:
                    break
            tf = caixa(s, tx, Inches(1.85), tw, Inches(4.1), "", tam)
            primeiro = True
            for l in corpo:
                p = tf.paragraphs[0] if primeiro else tf.add_paragraph()
                primeiro = False
                if l.startswith("- "):
                    par(p, "•  " + l[2:], tam, TINTA)
                else:
                    par(p, l, tam, TINTA)
                p.space_after = Pt(18 if corpo_fixo else 10)
        if visual:
            vx, vy, vw, vh = Inches(5.9), Inches(1.85), Inches(6.9), Inches(4.15)
            if not corpo:
                vx, vw = Inches(0.6), Inches(12.1)
            if visual[0] == "numero":
                numero(s, visual[1], vx, vy, vw, vh)
            else:
                g = visual[1]
                {"barras": grafico_barras, "anos": grafico_anos, "linhas": grafico_linhas,
                 "halteres": grafico_halteres}[g["tipo"]](s, g, dados, vx, vy, vw, vh)
        if conds:
            tf = caixa(s, Inches(0.6), Inches(6.05), Inches(12.1), Inches(0.6), "", 13)
            for k, c in enumerate(conds):
                p = tf.paragraphs[0] if k == 0 else tf.add_paragraph()
                par(p, c, 13, TINTA3)
        linha(s, Inches(0.6), Inches(6.78), Inches(12.7), Inches(6.78), GRADE, 0.75)
        caixa(s, Inches(0.6), Inches(6.82), Inches(12.1), Inches(0.55), cfg["rodape"], 10, TINTA2)
        if notas:
            s.notes_slide.notes_text_frame.text = "\n".join(n for n in notas if n)
    prs.core_properties.author = "Protótipo (agente de lançamento)"
    prs.save(saida)
    print("ok", saida, len(blocos), "slides")


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


if __name__ == "__main__":
    if len(sys.argv) < 5:
        raise SystemExit(__doc__)
    montar(sys.argv[1], sys.argv[2], json.load(open(sys.argv[3], encoding="utf-8")),
           json.load(open(sys.argv[4], encoding="utf-8")))
