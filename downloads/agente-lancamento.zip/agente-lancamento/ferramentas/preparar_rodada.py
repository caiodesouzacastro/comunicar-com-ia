"""Prepara a pasta de uma rodada de conferência e extrai o texto da peça montada.

Uso:
    python preparar_rodada.py <pasta_do_caso> <id_da_peça> <rodada>

Cria saida/conferencia/<peça>/rodada-<N>/ e grava texto-da-peca.txt, tirado do arquivo
indicado em lancamento.json (campo "arquivo" da peça). Também diz se a rodada anterior
exige nova rodada pelo critério de parada do CLAUDE.md.
"""
import json
import subprocess
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
TRAVAM = {"numero_errado", "condicao_faltando_ou_trocada"}


def precisa_de_nova_rodada(pasta_peca, n):
    if n <= 1:
        return True, "primeira rodada"
    ant = pasta_peca / f"rodada-{n - 1}"
    v = json.loads((ant / "verificador.json").read_text(encoding="utf-8"))
    travas = sum(1 for it in v.get("itens", []) if (it.get("classificacao") or "") in TRAVAM)
    ed = ant / "editor.json"
    mexeu = False
    if ed.exists():
        e = json.loads(ed.read_text(encoding="utf-8"))
        mexeu = any(d.get("mexeu_em_numero_ou_condicao") and d.get("decisao") == "corrigido" for d in e.get("decisoes", []))
    if travas:
        return True, f"rodada {n - 1} achou {travas} número(s) errado(s) ou condição(ões) faltando"
    if mexeu:
        return True, f"rodada {n - 1} zerou, mas o editor mexeu em número ou condição"
    return False, f"rodada {n - 1} zerou e o editor não mexeu em número nem condição"


def main():
    if len(sys.argv) < 4:
        raise SystemExit(__doc__)
    caso = Path(sys.argv[1]).resolve()
    peca = sys.argv[2]
    n = int(sys.argv[3])
    cfg = json.loads((caso / "lancamento.json").read_text(encoding="utf-8"))
    info = next(p for p in cfg["pecas"] if p["id"] == peca)
    pasta_peca = caso / "saida" / "conferencia" / peca
    nova, motivo = precisa_de_nova_rodada(pasta_peca, n)
    print(("NOVA RODADA: " if nova else "PARAR: ") + motivo)
    if not nova or n > 3:
        if n > 3:
            print("PARAR: limite de três rodadas")
        return
    pasta = pasta_peca / f"rodada-{n}"
    pasta.mkdir(parents=True, exist_ok=True)
    arquivo = caso / info["arquivo"]
    r = subprocess.run([sys.executable, "-I", str(AQUI / "texto_da_peca.py"), str(arquivo), str(pasta / "texto-da-peca.txt")],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    print(r.stdout.strip() or r.stderr.strip())


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


if __name__ == "__main__":
    main()
