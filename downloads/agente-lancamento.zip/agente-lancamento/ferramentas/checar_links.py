"""Confere links e recursos de páginas HTML que precisam abrir sem internet.

Uso:
    python checar_links.py <pagina.html> [<pagina2.html> ...]

Para cada página (depois de o JavaScript rodar, pelo Chrome sem interface):
  - todo href/src relativo precisa apontar para um arquivo que existe;
  - âncoras (#id) precisam existir na página;
  - nada pode depender de internet (http://, https://, //), a não ser links mailto:;
  - caminhos absolutos do disco (C:\\..., file://) são erro, porque quebram no zip.
Sai com código 1 se houver qualquer problema.
"""
import re
import subprocess
import sys
import tempfile
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit

CHROME = [r"C:\Program Files\Google\Chrome\Application\chrome.exe",
          r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
          r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"]


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.refs = []
        self.ids = set()

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if a.get("id"):
            self.ids.add(a["id"])
        if a.get("name") and tag == "a":
            self.ids.add(a["name"])
        for k in ("href", "src", "poster", "data-src"):
            if a.get(k) and not (tag == "base"):
                self.refs.append((tag, k, a[k]))
        if a.get("srcset"):
            for parte in a["srcset"].split(","):
                self.refs.append((tag, "srcset", parte.strip().split(" ")[0]))
        if a.get("style"):
            for u in re.findall(r"url\(([^)]+)\)", a["style"]):
                self.refs.append((tag, "style", u.strip("'\" ")))


def dom(url):
    chrome = next(c for c in CHROME if Path(c).exists())
    with tempfile.TemporaryDirectory() as perfil:
        r = subprocess.run([chrome, "--headless=new", "--disable-gpu", "--window-size=1366,768", f"--user-data-dir={perfil}",
                            "--virtual-time-budget=5000", "--dump-dom", url], capture_output=True, timeout=180)
    return r.stdout.decode("utf-8", "replace")


def checar(pagina):
    pagina = Path(pagina).resolve()
    fonte = pagina.read_text(encoding="utf-8")
    html = dom(pagina.as_uri())
    p = Links()
    p.feed(html)
    problemas = []
    for u in re.findall(r"url\(([^)]+)\)", fonte):
        u = u.strip("'\" ")
        if u.startswith(("http:", "https:", "//")):
            problemas.append(f"CSS depende de internet: {u}")
    for m in re.finditer(r"@import|fonts\.googleapis|cdn\.|unpkg\.com|jsdelivr", fonte):
        problemas.append(f"referência externa no código: {m.group()}")
    ok = 0
    for tag, attr, ref in p.refs:
        if ref.startswith(("data:", "mailto:", "javascript:")) or ref == "#":
            ok += 1
            continue
        if ref.startswith(("http:", "https:", "//")):
            problemas.append(f"{tag}[{attr}] depende de internet: {ref}")
            continue
        if re.match(r"^(file:|[A-Za-z]:[\\/]|/)", ref):
            problemas.append(f"{tag}[{attr}] caminho absoluto: {ref}")
            continue
        partes = urlsplit(ref)
        if not partes.path:
            frag = partes.fragment
            if frag and not frag.startswith("aba=") and frag not in p.ids:
                problemas.append(f"{tag}[{attr}] âncora inexistente: #{frag}")
            else:
                ok += 1
            continue
        alvo = (pagina.parent / unquote(partes.path)).resolve()
        if not alvo.exists():
            problemas.append(f"{tag}[{attr}] arquivo não existe: {ref}")
        else:
            ok += 1
    return ok, problemas


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    total = 0
    for pg in sys.argv[1:]:
        ok, probs = checar(pg)
        total += len(probs)
        print(f"{Path(pg).name}: {ok} links ok, {len(probs)} problema(s)")
        for pr in probs:
            print("   -", pr)
    sys.exit(1 if total else 0)


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


if __name__ == "__main__":
    main()
