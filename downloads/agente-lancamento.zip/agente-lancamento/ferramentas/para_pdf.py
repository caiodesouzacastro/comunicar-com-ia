"""Converte .docx (Word) ou .pptx (PowerPoint) em PDF pelo próprio Office, via COM, sem reparo.
Informa o número de páginas e, se pedido, grava a primeira página como PNG (miniatura).

Uso (Windows, Python com pywin32 e PyMuPDF):
    python para_pdf.py <arquivo.docx|.pptx> <saida.pdf> [miniatura.png] [largura_px]

O PowerPoint abre a cópia em somente leitura e sem janela; se o arquivo pedisse reparo,
a abertura falha e o erro aparece aqui (nada é consertado em silêncio).
"""
import os
import sys
from pathlib import Path

import pythoncom
import win32com.client


def docx_para_pdf(origem, destino):
    word = win32com.client.DispatchEx("Word.Application")
    word.Visible = False
    word.DisplayAlerts = 0
    try:
        doc = word.Documents.Open(str(origem), ConfirmConversions=False, ReadOnly=True, AddToRecentFiles=False,
                                  Visible=False, OpenAndRepair=False, NoEncodingDialog=True)
        doc.ExportAsFixedFormat(OutputFileName=str(destino), ExportFormat=17)
        paginas = doc.ComputeStatistics(2)  # wdStatisticPages
        doc.Close(SaveChanges=0)
    finally:
        word.Quit()
    return paginas


def pptx_para_pdf(origem, destino):
    # O PowerPoint tem uma instância só: se a pessoa estiver com apresentações abertas,
    # DispatchEx devolve o PowerPoint dela. Nesse caso fechamos só a nossa cópia e não
    # encerramos o programa, para não fechar o trabalho de ninguém.
    pp = win32com.client.DispatchEx("PowerPoint.Application")
    ja_abertas = pp.Presentations.Count
    apres = None
    try:
        apres = pp.Presentations.Open(str(origem), -1, 0, 0)  # ReadOnly, Untitled=False, WithWindow=False
        n = apres.Slides.Count
        faixa = apres.PrintOptions.Ranges.Add(1, n)
        apres.ExportAsFixedFormat(str(destino), 2, 2, 0, 1, 1, 0, faixa, 4, "", True, True, True, True, False)
    finally:
        if apres is not None:
            apres.Close()
        if ja_abertas == 0 and pp.Presentations.Count == 0:
            pp.Quit()
    return n


def miniatura(pdf, png, largura=600):
    import fitz
    d = fitz.open(str(pdf))
    pg = d[0]
    zoom = largura / pg.rect.width
    pg.get_pixmap(matrix=fitz.Matrix(zoom, zoom)).save(str(png))
    n = d.page_count
    d.close()
    return n


def main():
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    origem = Path(sys.argv[1]).resolve()
    destino = Path(sys.argv[2]).resolve()
    pythoncom.CoInitialize()
    if origem.suffix.lower() == ".docx":
        n = docx_para_pdf(origem, destino)
    elif origem.suffix.lower() == ".pptx":
        n = pptx_para_pdf(origem, destino)
    else:
        raise SystemExit("formato não suportado: " + origem.suffix)
    print(f"ok {destino} páginas={n}")
    if len(sys.argv) > 3:
        larg = int(sys.argv[4]) if len(sys.argv) > 4 else 600
        miniatura(destino, Path(sys.argv[3]).resolve(), larg)
        print("miniatura", sys.argv[3])


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


if __name__ == "__main__":
    main()
