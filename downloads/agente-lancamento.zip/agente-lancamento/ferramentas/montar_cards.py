"""Monta cards para redes sociais (HTML de arquivo único) e renderiza cada um em PNG 1080x1350.

Uso:
    python montar_cards.py <cards.json> <pasta_saida> <lancamento.json> <dados.json>

cards.json:
{"cards": [
  {"id": "card-1",
   "chamada": "frase curta no topo",
   "numero": "R$ 12,3 bilhões",            (opcional)
   "numero_rotulo": "o que o número é",     (opcional)
   "texto": "uma ou duas frases; **negrito** permitido",
   "grafico": {"tipo": "barras", ...},      (opcional; mesmo formato de montar_pptx.py, lido de dados.json)
   "condicao": "cenário · rede · referência · ano · N",
   "de_onde_vem": "Resumo, p. 4; Relatório, Tabela 2.1, p. 30"}
 ],
 "regras": {"max_palavras": 25, "max_linhas_condicao": 1}}   (opcional, para versões curtas;
                                                              um card pode trazer "max_palavras" próprio)
Gera <id>.html e <id>.png. Acusa o card cujo conteúdo não coube em 1080x1350 e, se houver "regras",
o que passar de max_palavras (chamada, rótulo do número, texto e condição; fora o número, a fonte e o
rodapé) ou de max_linhas_condicao (linhas da condição como renderizada).
"""
import html
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
CHROME = [r"C:\Program Files\Google\Chrome\Application\chrome.exe",
          r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
          r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"]


def navegador():
    for c in CHROME:
        if Path(c).exists():
            return c
    raise SystemExit("Chrome/Edge não encontrado")


def esc(t):
    t = html.escape(t or "")
    return re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", t)


def celula(tabela, chaves):
    for l in tabela["linhas"]:
        if all(str(l.get(k)) == str(v) for k, v in chaves.items()):
            return l
    raise SystemExit(f"linha não encontrada em {tabela['nome']}: {chaves}")


def svg_barras(g, dados):
    tab = dados["tabelas"][g["tabela"]]
    nomes = g.get("nomes", g["linhas"])
    vals = [celula(tab, {**g.get("filtro", {}), g["chave"]: l})["valores"][g["coluna"]] for l in g["linhas"]]
    W, rot_w, val_w = 960, 250, 230
    passo, bh = 62, 38
    H = passo * len(vals) + 10
    area_w = W - rot_w - 2 * val_w
    vmin = min(0, min(v["v"] for v in vals))
    vmax = max(0, max(v["v"] for v in vals))
    esc_ = area_w / (vmax - vmin if vmax > vmin else 1)
    zero = rot_w + val_w + (-vmin) * esc_
    partes = [f'<svg viewBox="0 0 {W} {H}" width="{W}" height="{H}" role="img" aria-label="{html.escape(g.get("titulo", ""))}">']
    for i, (n, v) in enumerate(zip(nomes, vals)):
        y = 5 + i * passo
        comp = abs(v["v"]) * esc_
        neg = v["v"] < 0
        cor = ("var(--libera)" if neg else "var(--exige)") if g.get("sinal") else "var(--c1)"
        x = zero - comp if neg else zero
        partes.append(f'<text x="{rot_w - 12}" y="{y + bh * 0.72:.0f}" text-anchor="end" class="rot">{html.escape(n)}</text>')
        partes.append(f'<rect x="{x:.1f}" y="{y}" width="{max(comp, 1):.1f}" height="{bh}" rx="4" fill="{cor}"/>')
        t = v["t"][1:] if v["t"].startswith("-") else v["t"]
        if g.get("sinal") and all(ch in "-0,." for ch in v["t"]):
            lab = "zero " + t + g.get("sufixo", "")
        elif g.get("sinal"):
            lab = (g.get("negativo", "libera") if neg else g.get("positivo", "exige")) + " " + t + g.get("sufixo", "")
        else:
            lab = v["t"] + g.get("sufixo", "")
        lx = x - 12 if neg else x + comp + 12
        partes.append(f'<text x="{lx:.1f}" y="{y + bh * 0.72:.0f}" text-anchor="{"end" if neg else "start"}" class="val">{html.escape(lab)}</text>')
    partes.append(f'<line x1="{zero:.1f}" x2="{zero:.1f}" y1="0" y2="{H}" stroke="var(--eixo)" stroke-width="2"/>')
    partes.append("</svg>")
    tit = f'<div class="gtitulo">{esc(g.get("titulo", ""))}</div>' if g.get("titulo") else ""
    return tit + "".join(partes)


def card_html(c, cfg, dados, css, classe=""):
    blocos = [f'<div class="chamada">{esc(c["chamada"])}</div>', '<div class="meio">']
    if c.get("numero"):
        blocos.append(f'<div class="numero">{esc(c["numero"])}</div>')
        if c.get("numero_rotulo"):
            blocos.append(f'<div class="numero-rotulo">{esc(c["numero_rotulo"])}</div>')
    if c.get("texto"):
        blocos.append(f'<p class="texto">{esc(c["texto"])}</p>')
    if c.get("grafico"):
        blocos.append(f'<div class="grafico">{svg_barras(c["grafico"], dados)}</div>')
    blocos.append('</div><div class="pe">')
    blocos.append(f'<div class="cond">{esc(c.get("condicao", ""))}</div>')
    blocos.append(f'<div class="fonte">De onde vem: {esc(c.get("de_onde_vem", ""))}</div>')
    blocos.append('</div>')
    return f"""<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=1080">
<title>{html.escape(c["id"])}</title>
<style>
{css}
html, body {{ width: 1080px; height: 1350px; margin: 0; overflow: hidden; }}
body {{ background: var(--superficie); font-size: 30px; }}
.quadro {{ box-sizing: border-box; width: 1080px; height: 1350px; padding: 72px 64px 0; display: flex; flex-direction: column; }}
.conteudo {{ flex: 1; display: flex; flex-direction: column; gap: 26px; min-height: 0; }}
.meio {{ display: flex; flex-direction: column; gap: 26px; margin: auto 0; }}
.pe {{ display: flex; flex-direction: column; gap: 18px; }}
.chamada {{ font-size: 52px; font-weight: 700; line-height: 1.15; }}
.numero {{ font-size: 112px; font-weight: 750; line-height: 1; letter-spacing: -1px; font-variant-numeric: tabular-nums; }}
.numero-rotulo {{ font-size: 32px; color: var(--tinta-2); margin-top: -10px; }}
.texto {{ font-size: 34px; line-height: 1.35; max-width: none; margin: 0; }}
.gtitulo {{ font-size: 26px; color: var(--tinta-2); font-weight: 600; margin-bottom: 10px; }}
.grafico .rot {{ font-size: 26px; fill: var(--tinta); }}
.grafico .val {{ font-size: 26px; fill: var(--tinta); font-variant-numeric: tabular-nums; }}
.cond {{ font-size: 25px; color: var(--tinta-3); line-height: 1.35; border-left: 6px solid var(--grade); padding-left: 16px; }}
.fonte {{ font-size: 23px; color: var(--tinta-2); }}
.compacto .conteudo, .compacto .meio {{ gap: 16px; }}
.compacto .pe {{ gap: 10px; }}
.compacto .texto {{ font-size: 32px; line-height: 1.3; }}
.compacto .cond {{ font-size: 23px; }}
.compacto .fonte {{ font-size: 21px; }}
.rodape {{ font-size: 19px; color: var(--tinta-2); line-height: 1.35; border-top: 2px solid var(--grade); padding: 18px 0 30px; margin-top: 18px; }}
</style></head>
<body class="{classe}"><div class="quadro"><div class="conteudo">
{chr(10).join(blocos)}
</div><div class="rodape">{esc(cfg["rodape"])}</div></div>
<script>
  var q = document.querySelector('.quadro');
  var c = document.querySelector('.conteudo');
  var r = document.querySelector('.rodape');
  var soma = c.scrollHeight + r.offsetHeight + 72 + 18;
  document.body.setAttribute('data-transborda', (soma > 1350 || c.scrollHeight > c.clientHeight + 1) ? 'sim' : 'nao');
  var cd = document.querySelector('.cond');
  if (cd) {{ var lh = parseFloat(getComputedStyle(cd).lineHeight); document.body.setAttribute('data-linhas-cond', Math.round(cd.getBoundingClientRect().height / lh)); }}
</script>
</body></html>"""


def renderizar(chrome, html_path, png_path):
    url = Path(html_path).resolve().as_uri()
    with tempfile.TemporaryDirectory() as perfil:
        subprocess.run([chrome, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--force-device-scale-factor=1",
                        "--window-size=1080,1350", f"--user-data-dir={perfil}", f"--screenshot={png_path}", url],
                       capture_output=True, timeout=120)
        dom = subprocess.run([chrome, "--headless=new", "--disable-gpu", "--window-size=1080,1350",
                              f"--user-data-dir={perfil}", "--dump-dom", url],
                             capture_output=True, timeout=120).stdout.decode("utf-8", "replace")
    m = re.search(r'data-linhas-cond="(\d+)"', dom)
    return 'data-transborda="sim"' in dom, int(m.group(1)) if m else 0


def main():
    if len(sys.argv) < 5:
        raise SystemExit(__doc__)
    entrada = json.load(open(sys.argv[1], encoding="utf-8"))
    cards = entrada["cards"]
    regras = entrada.get("regras", {})
    pasta = Path(sys.argv[2])
    cfg = json.load(open(sys.argv[3], encoding="utf-8"))
    dados = json.load(open(sys.argv[4], encoding="utf-8"))
    css = (AQUI / "estilo.css").read_text(encoding="utf-8")
    pasta.mkdir(parents=True, exist_ok=True)
    chrome = navegador()
    problemas = []
    for c in cards:
        h = pasta / f"{c['id']}.html"
        h.write_text(card_html(c, cfg, dados, css), encoding="utf-8")
        png = pasta / f"{c['id']}.png"
        transborda, linhas_cond = renderizar(chrome, h, png)
        if transborda:
            # Não coube: tenta de novo com espaçamentos e corpo um pouco menores, sem mudar o texto.
            h.write_text(card_html(c, cfg, dados, css, "compacto"), encoding="utf-8")
            transborda, linhas_cond = renderizar(chrome, h, png)
            if transborda:
                problemas.append(c["id"])
            else:
                print("compactado", c["id"])
        if regras.get("max_palavras"):
            texto_contado = " ".join(c.get(k, "") for k in ("chamada", "numero_rotulo", "texto", "condicao"))
            n_pal = len(re.findall(r"[\wÀ-ÿ$%,.\-]+", re.sub(r"\*\*", "", texto_contado)))
            limite = c.get("max_palavras", regras["max_palavras"])  # um card pode ter limite próprio
            print(f"   {c['id']}: {n_pal} palavras (máx. {limite}), condição em {linhas_cond} linha(s)")
            if n_pal > limite:
                problemas.append(f"{c['id']} ({n_pal} palavras)")
        if regras.get("max_linhas_condicao") and linhas_cond > regras["max_linhas_condicao"]:
            problemas.append(f"{c['id']} (condição em {linhas_cond} linhas)")
        try:
            from PIL import Image
            tam = Image.open(png).size
        except Exception:
            tam = "?"
        print("ok", png, tam)
    if problemas:
        print("NÃO COUBE OU PASSOU DAS REGRAS:", ", ".join(problemas))
        sys.exit(2)


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


if __name__ == "__main__":
    main()
