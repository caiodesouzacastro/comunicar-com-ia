"""Monta o pacote zip para a equipe e confere os links depois de extraído.

Uso:
    python montar_pacote.py <pasta_do_caso> <arquivo.zip>

Entra no zip, na raiz:
  painel.html                 gerado de novo com montar_painel.py --pacote (link do README ao lado)
  as peças de lancamento.json (campo "arquivo"; pastas entram inteiras)
  rastreabilidade.xlsx
  agente-lancamento/          a pasta do agente, sem __pycache__
Não entram: fonte/ (PDFs), saida/prints/, dados.json solto, conferência, scripts do caso.

Depois de gravar, extrai o zip numa pasta temporária, roda checar_links.py em todas as
páginas HTML da raiz e informa o SHA256 do zip. Sai com código 1 se algum link quebrar.
"""
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent


def main():
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    caso = Path(sys.argv[1]).resolve()
    destino = Path(sys.argv[2]).resolve()
    cfg = json.loads((caso / "lancamento.json").read_text(encoding="utf-8"))
    saida = caso / "saida"
    with tempfile.TemporaryDirectory() as tmp:
        painel = Path(tmp) / "painel.html"
        r = subprocess.run([sys.executable, "-I", str(AQUI / "montar_painel.py"), str(caso), "--pacote", "--saida", str(painel)],
                           capture_output=True, text=True, encoding="utf-8", errors="replace")
        if r.returncode != 0 or not painel.exists():
            raise SystemExit("falha ao montar o painel do pacote:\n" + r.stdout + r.stderr)
        itens = [(painel, "painel.html")]
        for p in cfg["pecas"]:
            alvo = caso / p["arquivo"]
            rel = alvo.relative_to(saida)
            if alvo.is_dir():
                for f in sorted(alvo.rglob("*")):
                    if f.is_file():
                        itens.append((f, f.relative_to(saida).as_posix()))
            else:
                itens.append((alvo, rel.as_posix()))
        itens.append((saida / "rastreabilidade.xlsx", "rastreabilidade.xlsx"))
        agente = caso / "agente-lancamento"
        for f in sorted(agente.rglob("*")):
            if f.is_file() and "__pycache__" not in f.parts:
                itens.append((f, "agente-lancamento/" + f.relative_to(agente).as_posix()))
        destino.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
            for origem, nome in itens:
                z.write(origem, nome)
        print(f"zip: {destino} ({len(itens)} arquivos, {destino.stat().st_size:,} bytes)".replace(",", "."))

    with tempfile.TemporaryDirectory() as tmp:
        with zipfile.ZipFile(destino) as z:
            z.extractall(tmp)
        paginas = sorted(Path(tmp).glob("*.html"))
        r = subprocess.run([sys.executable, "-I", str(AQUI / "checar_links.py"), *map(str, paginas)],
                           capture_output=True, text=True, encoding="utf-8", errors="replace")
        print("links no zip extraído:")
        print(r.stdout.strip())
        ok = r.returncode == 0
    h = hashlib.sha256(destino.read_bytes()).hexdigest().upper()
    print("SHA256", h)
    sys.exit(0 if ok else 1)


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


if __name__ == "__main__":
    main()
