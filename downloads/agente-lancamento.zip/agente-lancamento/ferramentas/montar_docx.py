"""Monta um .docx sóbrio a partir de um texto em marcação simples.

Uso:
    python montar_docx.py <entrada.md> <saida.docx> <lancamento.json>

Marcação aceita (uma por linha):
    <!-- docx: corpo=10.5 margem=2.0 titulo=18 colunas=1 -->   opções (primeira linha, opcional)
    # Título                 título da peça
    ## Seção                 seção
    ### Subseção             subseção (ou pergunta, numa nota de imprensa)
    texto                    parágrafo (linhas seguidas viram um parágrafo; linha vazia separa)
    - item                   lista
    > texto                  nota de condição / "de onde vem" (menor, cinza)
    | a | b |                tabela (a 2.ª linha |---| separa o cabeçalho)
    <!-- quebra -->          quebra de página
    ^ texto                  nota de pé de página: vai para o rodapé de todas as páginas, acima do rodapé
                             de protótipo (marque a chamada no texto com algarismo sobrescrito, ¹ ² ³...)
Dentro do texto: **negrito** e *itálico*.
O rodapé de protótipo vem de lancamento.json (campo "rodape") e vai no rodapé de todas as páginas.
"""
import json
import re
import sys

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

TINTA = RGBColor(0x0B, 0x0B, 0x0B)
TINTA2 = RGBColor(0x52, 0x51, 0x4E)
TINTA3 = RGBColor(0x6B, 0x6A, 0x66)
FONTE = "Calibri"


def opcoes(linhas):
    op = {"corpo": 10.5, "margem": 2.0, "titulo": 18.0, "secao": 13.0, "nota": 8.5, "tabela": 9.0, "espaco": 4.0}
    if linhas and linhas[0].startswith("<!-- docx:"):
        for k, v in re.findall(r"(\w+)=([\d.]+)", linhas[0]):
            op[k] = float(v)
        linhas = linhas[1:]
    return op, linhas


def runs(par, texto, tamanho, cor=TINTA, negrito=False, italico=False):
    partes = re.split(r"(\*\*[^*]+\*\*|\*[^*]+\*)", texto)
    for p in partes:
        if not p:
            continue
        b, i = negrito, italico
        if p.startswith("**") and p.endswith("**"):
            p, b = p[2:-2], True
        elif p.startswith("*") and p.endswith("*") and len(p) > 1:
            p, i = p[1:-1], True
        r = par.add_run(p)
        r.font.size = Pt(tamanho)
        r.font.name = FONTE
        r.font.color.rgb = cor
        r.bold = b
        r.italic = i


def espaco(par, antes=0, depois=4, linha=1.1):
    pf = par.paragraph_format
    pf.space_before = Pt(antes)
    pf.space_after = Pt(depois)
    pf.line_spacing = linha


def sombrear(celula, cor_hex):
    tcPr = celula._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), cor_hex)
    tcPr.append(shd)


def bordas_tabela(tabela):
    tblPr = tabela._tbl.tblPr
    bordas = OxmlElement("w:tblBorders")
    for nome in ("top", "bottom", "insideH"):
        el = OxmlElement(f"w:{nome}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "4")
        el.set(qn("w:color"), "C3C2B7")
        bordas.append(el)
    for nome in ("left", "right", "insideV"):
        el = OxmlElement(f"w:{nome}")
        el.set(qn("w:val"), "nil")
        bordas.append(el)
    tblPr.append(bordas)


def adicionar_tabela(doc, linhas_tab, op):
    celulas = [[c.strip() for c in l.strip().strip("|").split("|")] for l in linhas_tab]
    cab = celulas[0]
    corpo = [c for c in celulas[1:] if not all(re.fullmatch(r":?-{2,}:?", x) for x in c)]
    t = doc.add_table(rows=1 + len(corpo), cols=len(cab))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    bordas_tabela(t)
    for j, txt in enumerate(cab):
        c = t.rows[0].cells[j]
        c.text = ""
        runs(c.paragraphs[0], txt, op["tabela"], TINTA2, negrito=True)
        sombrear(c, "F1F0EC")
        if j > 0:
            c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
    for i, linha in enumerate(corpo, start=1):
        for j in range(len(cab)):
            txt = linha[j] if j < len(linha) else ""
            c = t.rows[i].cells[j]
            c.text = ""
            runs(c.paragraphs[0], txt, op["tabela"])
            if j > 0:
                c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
    for row in t.rows:
        for c in row.cells:
            for p in c.paragraphs:
                espaco(p, 0, 0, 1.0)
    p = doc.add_paragraph()
    espaco(p, 0, 2)


def rodape(doc, texto, notas=()):
    for s in doc.sections:
        f = s.footer
        p = f.paragraphs[0]
        p.text = ""
        for n in notas:
            runs(p, n, 8, TINTA2)
            espaco(p, 0, 1, 1.0)
            p = f.add_paragraph()
        runs(p, texto, 7.5, TINTA2)
        espaco(p, 3 if notas else 0, 0, 1.0)


def montar(entrada, saida, cfg):
    linhas = open(entrada, encoding="utf-8").read().splitlines()
    op, linhas = opcoes(linhas)
    doc = Document()
    estilo = doc.styles["Normal"]
    estilo.font.name = FONTE
    estilo.font.size = Pt(op["corpo"])
    estilo.element.rPr.rFonts.set(qn("w:eastAsia"), FONTE)
    for s in doc.sections:
        s.page_height, s.page_width = Cm(29.7), Cm(21.0)
        s.left_margin = s.right_margin = Cm(op["margem"])
        s.top_margin = Cm(op["margem"])
        s.bottom_margin = Cm(op["margem"] + 0.3)
        s.footer_distance = Cm(0.8)
    buf = []
    tab = []
    notas_pe = []

    def solta_paragrafo():
        if buf:
            p = doc.add_paragraph()
            runs(p, " ".join(buf), op["corpo"])
            espaco(p, 0, op["espaco"], 1.12)
            buf.clear()

    def solta_tabela():
        if tab:
            adicionar_tabela(doc, tab, op)
            tab.clear()

    for l in linhas + [""]:
        s = l.rstrip()
        if s.startswith("|"):
            solta_paragrafo()
            tab.append(s)
            continue
        solta_tabela()
        if not s.strip():
            solta_paragrafo()
        elif s.strip() == "<!-- quebra -->":
            solta_paragrafo()
            doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
        elif s.startswith("# "):
            solta_paragrafo()
            p = doc.add_paragraph()
            runs(p, s[2:], op["titulo"], negrito=True)
            espaco(p, 0, 6, 1.0)
        elif s.startswith("## "):
            solta_paragrafo()
            p = doc.add_paragraph()
            runs(p, s[3:], op["secao"], negrito=True)
            espaco(p, 6, 3, 1.0)
            p.paragraph_format.keep_with_next = True
        elif s.startswith("### "):
            solta_paragrafo()
            p = doc.add_paragraph()
            runs(p, s[4:], op["corpo"] + 0.5, negrito=True)
            espaco(p, 5, 2, 1.05)
            p.paragraph_format.keep_with_next = True
        elif s.startswith("- "):
            solta_paragrafo()
            p = doc.add_paragraph(style="List Bullet")
            runs(p, s[2:], op["corpo"])
            espaco(p, 0, 2, 1.1)
        elif s.startswith("^ "):
            solta_paragrafo()
            notas_pe.append(s[2:].strip())
        elif s.startswith("> "):
            solta_paragrafo()
            p = doc.add_paragraph()
            runs(p, s[2:], op["nota"], TINTA3)
            espaco(p, 0, op["espaco"], 1.05)
        else:
            buf.append(s.strip())
    rodape(doc, cfg["rodape"], notas_pe)
    doc.core_properties.author = "Protótipo (agente de lançamento)"
    doc.core_properties.title = next((l[2:] for l in linhas if l.startswith("# ")), "")
    doc.save(saida)
    print("ok", saida)


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


if __name__ == "__main__":
    if len(sys.argv) < 4:
        raise SystemExit(__doc__)
    montar(sys.argv[1], sys.argv[2], json.load(open(sys.argv[3], encoding="utf-8")))
